<?php
        /*
        Plugin Name: SecurePay Bridge – Low Risk Site
        Plugin URI: https://securepaybridge.net
        Description: Seamlessly receive WooCommerce order data from a high-risk source and auto-initiate checkout in this low-risk store for secure and smooth payment processing.
        Version: 13.5.5
        Author: SecurePay Bridge
        Author URI: https://securepaybridge.net
        */

        /**
         * @package Woocomerce-Rest-B
         */

        if (!defined('ABSPATH')) exit; // Exit if accessed directly

        // Define plugin version constant (if not already defined)
        if (!defined('SECUREPAY_BRIDGE_VERSION')) {
            define('SECUREPAY_BRIDGE_VERSION', '13.5.5'); // Match the version in the header
        }

        // Load plugin settings
        require_once plugin_dir_path(__FILE__) . 'includes/securepay-settings.php';

        // Include the plugin updater class
        require_once plugin_dir_path(__FILE__) . 'includes/plugin-updater.php';

        // Instantiate the updater class
        // Pass the main plugin file path, the update server API URL, the plugin slug, and the current version.
        $securepay_bridge_updater = new SecurePay_Bridge_Updater(
            __FILE__, // Main plugin file path
            'https://auth.securepaybridge.net/update-check.php', // Your actual update server API endpoint
            plugin_basename(__FILE__), // Plugin slug (e.g., 'woocommerce-rest-b/woocommerce-rest-b.php')
            SECUREPAY_BRIDGE_VERSION // Current version constant
        );


        /**
         * Helper function for conditional debug logging.
         * Logs messages to the PHP error log only if debug is enabled in settings.
         *
         * @param string $message The message to log.
         */
        function securepay_bridge_log($message) {
            // Check if debug logging is enabled in plugin settings
            // Use get_option with default 0 (false)
            $debug_enabled = get_option('securepay_enable_debug', 0);

            if ($debug_enabled) {
                // Use error_log for standard PHP error logging
                error_log("[SecurePay Bridge] " . $message);
            }
        }


        // Handle incoming parameters and set cookies
        if (isset($_GET['total_amount'])) {
            $total_amount = floatval($_GET['total_amount']);
            $myordernow = isset($_GET['myordernow']) ? sanitize_text_field($_GET['myordernow']) : '';
            $myaffiliateurl = isset($_GET['myaffiliateurl']) ? urldecode(sanitize_url($_GET['myaffiliateurl'])) : ''; // Sanitize URL after decoding
            $order_key = isset($_GET['order_key']) ? sanitize_text_field($_GET['order_key']) : '';

            // Clear previous cookies
            setcookie('new_price', '', time() - 3600, '/');
            setcookie('myordernow', '', time() - 3600, '/');
            setcookie('myaffiliateurl', '', time() - 3600, '/');
            setcookie('order_key', '', time() - 3600, '/');

            // Set new cookies (valid for the session)
            setcookie('new_price', $total_amount, 0, '/');
            setcookie('myordernow', $myordernow, 0, '/');
            setcookie('myaffiliateurl', $myaffiliateurl, 0, '/');
            if (!empty($order_key)) {
                setcookie('order_key', $order_key, 0, '/');
            }

            securepay_bridge_log("Incoming parameters detected. Setting cookies: new_price={$total_amount}, myordernow={$myordernow}, myaffiliateurl={$myaffiliateurl}, order_key={$order_key}");

            // Add query vars to allow them in the URL
            add_filter('query_vars', function($vars) {
                $vars[] = 'total_amount';
                $vars[] = 'billing_first_name';
                $vars[] = 'billing_last_name';
                $vars[] = 'billing_email';
                $vars[] = 'billing_company';
                $vars[] = 'billing_address_1';
                $vars[] = 'billing_address_2';
                $vars[] = 'billing_city';
                $vars[] = 'billing_state';
                $vars[] = 'billing_postcode';
                $vars[] = 'billing_country';
                $vars[] = 'billing_phone';
                $vars[] = 'currency';
                $vars[] = 'myordernow';
                $vars[] = 'myaffiliateurl';
                $vars[] = 'order_key';
                return $vars;
            });
        }

        // Redirect to checkout and populate cart/customer data
        add_action('template_redirect', function () {
            // Only run this logic if total_amount is present in the URL or cookie
            $incoming_total_amount = null;
            if (isset($_GET['total_amount'])) {
                 $incoming_total_amount = floatval($_GET['total_amount']);
                 securepay_bridge_log("Incoming total_amount from GET: " . $incoming_total_amount);
            } elseif (isset($_COOKIE['new_price'])) {
                 $incoming_total_amount = floatval($_COOKIE['new_price']);
                 securepay_bridge_log("Incoming total_amount from COOKIE: " . $incoming_total_amount);
            }

            if ($incoming_total_amount === null) {
                securepay_bridge_log("No total_amount found in GET or COOKIE. Exiting template_redirect logic.");
                return; // Exit if no amount is available
            }

            // Don't run if already on checkout page
            if (is_checkout()) {
                securepay_bridge_log("Already on checkout page. Exiting template_redirect logic.");
                return;
            }

            // Ensure WooCommerce and Cart are available
            if (!function_exists('WC') || !WC()->cart) {
                securepay_bridge_log("WooCommerce or Cart not available. Exiting template_redirect logic.");
                return;
            }

            WC()->cart->empty_cart();
            securepay_bridge_log("Cart emptied.");

            $product_id_to_add = null;
            $selection_mode = get_option('securepay_product_selection_mode', 'random');
            securepay_bridge_log("Product Selection Mode: " . $selection_mode);
            securepay_bridge_log("Incoming Total Amount for Selection Logic: " . $incoming_total_amount);


            // --- Product Selection Logic based on Mode ---

            if ($selection_mode === 'conditional_price') {
                $price_conditions = get_option('securepay_price_conditions', []);
                securepay_bridge_log("Evaluating Price Conditions: " . print_r($price_conditions, true));

                if (!empty($price_conditions) && is_array($price_conditions)) {
                    foreach ($price_conditions as $condition) {
                        $min_amount = isset($condition['min_amount']) && is_numeric($condition['min_amount']) ? floatval($condition['min_amount']) : null;
                        $max_amount = isset($condition['max_amount']) && is_numeric($condition['max_amount']) ? floatval($condition['max_amount']) : null;
                        $product_ids = isset($condition['product_ids']) && is_array($condition['product_ids']) ? $condition['product_ids'] : [];

                        $match = true; // Assume match initially

                        // Check min amount condition
                        if ($min_amount !== null && $incoming_total_amount < $min_amount) {
                            $match = false;
                        }

                        // Check max amount condition (only if min condition passed)
                        if ($match && $max_amount !== null && $incoming_total_amount > $max_amount) {
                            $match = false;
                        }

                        // If match is true and we have valid product IDs
                        if ($match && !empty($product_ids)) {
                            // Pick a random product ID from the list for this condition
                            $chosen_product_id = $product_ids[array_rand($product_ids)];
                            $product_id_to_add = $chosen_product_id;
                            securepay_bridge_log("Price Condition Matched: Min=" . ($min_amount ?? 'N/A') . ", Max=" . ($max_amount ?? 'N/A') . ". Randomly selected Product ID: " . $product_id_to_add . " from [" . implode(',', $product_ids) . "]");
                            break; // First match wins
                        } else {
                             securepay_bridge_log("Condition did not match or had no valid products: Min=" . ($min_amount ?? 'N/A') . ", Max=" . ($max_amount ?? 'N/A') . ", Product IDs: " . (empty($product_ids) ? 'None' : implode(',', $product_ids)));
                        }
                    }
                } else {
                     securepay_bridge_log("No price conditions configured.");
                }

                 if ($product_id_to_add === null) {
                     securepay_bridge_log("No price condition matched. Falling back to default random selection.");
                 }

            } elseif ($selection_mode === 'specific_product') {
                $selected_products = get_option('securepay_selected_products', []);
                if (!empty($selected_products)) {
                    if (count($selected_products) === 1) {
                        $product_id_to_add = $selected_products[0];
                        securepay_bridge_log("Specific Product Mode: Adding single specific product ID: " . $product_id_to_add);
                    } else {
                        $product_id_to_add = $selected_products[array_rand($selected_products)];
                        securepay_bridge_log("Specific Product Mode: Adding random product from selected list. Chosen ID: " . $product_id_to_add);
                    }
                } else {
                     securepay_bridge_log("Specific Product Mode selected but no products specified. Falling back.");
                }

            } elseif ($selection_mode === 'specific_category') {
                $selected_categories = get_option('securepay_selected_categories', []);
                if (!empty($selected_categories)) {
                    $args = [
                        'status' => 'publish',
                        'limit'  => -1,
                        'return' => 'ids',
                        'tax_query' => [
                            [
                                'taxonomy' => 'product_cat',
                                'field'    => 'term_id',
                                'terms'    => $selected_categories,
                            ],
                        ],
                    ];
                    $products_in_cats = wc_get_products($args);

                    if (!empty($products_in_cats)) {
                        $product_id_to_add = $products_in_cats[array_rand($products_in_cats)];
                        securepay_bridge_log("Specific Category Mode: Adding random product from selected categories. Chosen ID: " . $product_id_to_add);
                    } else {
                        securepay_bridge_log("Specific Category Mode: No published products found in selected categories. Falling back.");
                    }
                } else {
                     securepay_bridge_log("Specific Category Mode selected but no categories specified. Falling back.");
                }
            }

            // --- Fallback / Default Random Selection ---
            // This runs if mode is 'random' OR if the selected mode failed to find a product ID
            if ($product_id_to_add === null) {
                if ($selection_mode !== 'random') {
                     securepay_bridge_log("Fallback Triggered: Mode '{$selection_mode}' failed to determine a product. Using default random selection.");
                } else {
                     securepay_bridge_log("Random Mode (Default): Selecting random product from all published products.");
                }

                $all_products_args = [
                    'post_type' => 'product',
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                    'fields' => 'ids',
                ];
                $all_products = get_posts($all_products_args);

                if (!empty($all_products)) {
                    $product_id_to_add = $all_products[array_rand($all_products)];
                    securepay_bridge_log("Default Random Selection: Chosen ID: " . $product_id_to_add);
                } else {
                    // Critical error: No products available at all
                    securepay_bridge_log("CRITICAL: No published products found in the store for default selection.");
                    wp_die('Error: No products available to add to cart.');
                }
            }

            // --- Add the determined product to the cart ---
            if ($product_id_to_add) {
                $result = WC()->cart->add_to_cart($product_id_to_add, 1);
                if (!$result) {
                     securepay_bridge_log("Failed to add product ID {$product_id_to_add} to cart.");
                     wp_die('An error occurred while adding the product to your cart.');
                } else {
                     securepay_bridge_log("Successfully added product ID {$product_id_to_add} to cart.");
                }
            } else {
                // This case should ideally not be reached if the fallback logic is correct
                securepay_bridge_log("CRITICAL ERROR: Could not determine any product ID to add to the cart after all checks.");
                wp_die('An error occurred while preparing your cart.'); // Generic error
            }

            // --- Populate customer billing details ---
            $fields = [
                'billing_first_name', 'billing_last_name', 'billing_email', 'billing_company',
                'billing_address_1', 'billing_address_2', 'billing_city', 'billing_state',
                'billing_postcode', 'billing_country', 'billing_phone'
            ];

            foreach ($fields as $field) {
                if (isset($_GET[$field])) {
                    $value = sanitize_text_field(urldecode($_GET[$field])); // Decode and sanitize
                    $method = 'set_' . $field;
                    if (method_exists(WC()->customer, $method)) {
                        WC()->customer->$method($value);
                        securepay_bridge_log("Set customer billing field '{$field}' to '{$value}'.");
                    } else {
                         securepay_bridge_log("Method '{$method}' does not exist on WC()->customer.");
                    }
                }
            }

            // --- Set currency ---
            if (isset($_GET['currency'])) {
                $currency_code = sanitize_text_field($_GET['currency']);
                if (array_key_exists($currency_code, get_woocommerce_currencies())) {
                    WC()->session->set('client_currency', $currency_code);
                    securepay_bridge_log("Set client currency in session to: " . $currency_code);
                } else {
                     securepay_bridge_log("Invalid currency code received: " . $currency_code);
                }
            }

            // --- Redirect to checkout ---
            if (!is_checkout()) {
                securepay_bridge_log("Redirecting to checkout page: " . wc_get_checkout_url());
                wp_safe_redirect(wc_get_checkout_url());
                exit;
            }
        });

        // Action to potentially change currency based on session before calculations
        add_action('woocommerce_before_calculate_totals', function ($cart) {
            if (is_admin() && !defined('DOING_AJAX')) return;

            // Check for client_currency session set in the redirect logic
            $client_currency = WC()->session->get('client_currency');
            if ($client_currency && $client_currency !== get_woocommerce_currency()) {
                // Temporarily change the currency for this cart calculation
                add_filter('woocommerce_currency', function($currency) use ($client_currency) {
                    securepay_bridge_log("Temporarily changing currency filter to: " . $client_currency);
                    return $client_currency;
                }, 9999); // High priority to override others
                 securepay_bridge_log("Temporarily setting currency to: " . $client_currency);
            }

            // Apply the custom price from the cookie
            // IMPORTANT: This price override happens AFTER the product selection logic.
            // The product selection uses the incoming total_amount, but the final price in the cart uses the cookie.
            if (isset($_COOKIE['new_price'])) {
                $new_price = floatval($_COOKIE['new_price']);
                securepay_bridge_log("Applying custom price from cookie: " . $new_price);
                foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
                    // Ensure it's a product object before setting price
                    if (isset($cart_item['data']) && $cart_item['data'] instanceof WC_Product) {
                        $cart_item['data']->set_price($new_price);
                        securepay_bridge_log("Set price for cart item '{$cart_item_key}' to {$new_price}.");
                    } else {
                         securepay_bridge_log("Warning: Could not set price for cart item key: " . $cart_item_key . ". Item data is not a WC_Product.");
                    }
                }
            }
        }, 20, 1);


        // Set currency on the order object and clear session currency
        add_action('woocommerce_checkout_create_order', function ($order, $data) {
            // Set currency on the order object itself if it was changed via session
            $client_currency = WC()->session->get('client_currency');
            if ($client_currency && $client_currency !== $order->get_currency()) {
                $order->set_currency($client_currency);
                securepay_bridge_log("Setting order currency for Order ID {$order->get_id()} to: " . $client_currency);
            }
            // Clear the session variable after use
            WC()->session->__unset('client_currency');
            securepay_bridge_log("Cleared client_currency session variable.");
        }, 10, 2);


        // Save external order data and clear cart after order is processed
        add_action('woocommerce_checkout_order_processed', function ($order_id, $posted_data, $order) {
            if (isset($_COOKIE['myordernow'])) {
                update_post_meta($order_id, 'external_order_id', sanitize_text_field($_COOKIE['myordernow']));
                securepay_bridge_log("Saved external_order_id '{$_COOKIE['myordernow']}' for Order ID {$order_id}.");
            }
            if (isset($_COOKIE['myaffiliateurl'])) {
                $hook_url = esc_url_raw(urldecode($_COOKIE['myaffiliateurl']));
                if ($hook_url) {
                    update_post_meta($order_id, 'hook_url', $hook_url);
                    securepay_bridge_log("Saved hook_url '{$hook_url}' for Order ID {$order_id}.");
                } else {
                     securepay_bridge_log("Failed to save hook_url for Order ID {$order_id}. Invalid URL after decoding/sanitizing.");
                }
            }
            if (isset($_COOKIE['order_key'])) {
                update_post_meta($order_id, 'order_key', sanitize_text_field($_COOKIE['order_key']));
                securepay_bridge_log("Saved external order_key '{$_COOKIE['order_key']}' for Order ID {$order_id}.");
            }

            // Clear cart after order is processed
             if (function_exists('WC') && WC()->cart) {
                WC()->cart->empty_cart();
                securepay_bridge_log("Cart emptied after order processing for Order ID {$order_id}.");
            }
        }, 10, 3);


        /**
         * Makes a request back to Site A to update order status.
         *
         * @param int    $order_id      The WooCommerce order ID.
         * @param string $endpoint_path The specific endpoint path on Site A.
         */
        function request_call_to_a($order_id, $endpoint_path) {
            $order = wc_get_order($order_id);
            if (!$order) {
                securepay_bridge_log("Could not retrieve order object for Order ID: $order_id when attempting to call Site A endpoint $endpoint_path.");
                return;
            }

            $hook_url = $order->get_meta('hook_url', true);
            $external_order_id = $order->get_meta('external_order_id', true);

            if (empty($hook_url) || empty($external_order_id)) {
                securepay_bridge_log("Missing hook_url ('{$hook_url}') or external_order_id ('{$external_order_id}') for Order ID: $order_id when calling endpoint $endpoint_path. Cannot notify Site A.");
                return;
            }

            // Basic URL validation
            if (filter_var($hook_url, FILTER_VALIDATE_URL) === FALSE) {
                 securepay_bridge_log("Invalid hook_url format for Order ID: $order_id. URL: $hook_url. Cannot notify Site A.");
                 return;
            }

            $url = rtrim($hook_url, '/') . '/wp-json/api/v2/' . ltrim($endpoint_path, '/'); // Ensure endpoint path is correctly formatted

            $fields = array(
                'order_id' => $external_order_id,
                'payment_method_title' => $order->get_payment_method_title(),
                'transaction_id' => $order->get_transaction_id(),
                'order_status' => $order->get_status(), // Send current status
            );

            $args = array(
                'body'        => $fields,
                'timeout'     => 15,
                'redirection' => 5,
                'httpversion' => '1.1',
                'user-agent'  => 'SecurePayBridgeWP/' . SECUREPAY_BRIDGE_VERSION . '; ' . home_url(), // Use defined constant
                'blocking'    => true,
                'headers'     => array('Content-Type' => 'application/x-www-form-urlencoded'),
                'cookies'     => array(),
                'sslverify'   => true, // Always verify SSL
            );

            securepay_bridge_log("Attempting to notify Site A for Order ID $order_id. Endpoint: $endpoint_path. URL: $url. Data: " . print_r($fields, true));

            $response = wp_remote_post($url, $args);

            if (is_wp_error($response)) {
                $error_message = $response->get_error_error_message(); // Correct function to get error message
                securepay_bridge_log("WP Error calling Site A for Order ID $order_id ($endpoint_path): " . $error_message);
            } else {
                $http_code = wp_remote_retrieve_response_code($response);
                $response_body = wp_remote_retrieve_body($response);
                if ($http_code >= 400) {
                     securepay_bridge_log("Site A returned HTTP error $http_code for Order ID $order_id ($endpoint_path). Response: " . substr($response_body, 0, 500));
                } else {
                     securepay_bridge_log("Successfully notified Site A for Order ID $order_id ($endpoint_path). HTTP Code: $http_code. Response: " . substr($response_body, 0, 500));
                }
            }
        }

        /**
         * Triggers the call to Site A based on order status slug.
         *
         * @param int    $order_id  The WooCommerce order ID.
         * @param string $status_slug The new order status slug.
         */
        function securepay_trigger_site_a_hook($order_id, $status_slug) {
            $endpoint_map = [
                'completed'  => 'wcwcwcwcwcw837378373773-order-completed',
                'refunded'   => 'wcwcwcwcwcw837378373773-order-refunded',
                'cancelled'  => 'wcwcwcwcwcw837378373773-order-cancelled',
                'processing' => 'wcwcwcwcwcw837378373773-order-processing',
                'on-hold'    => 'wcwcwcwcwcw837378373773-order-hold',
                'pending'    => 'wcwcwcwcwcw837378373773-order-pending',
                'failed'     => 'wcwcwcwcwcw837378373773-order-failed',
                'draft'      => 'wcwcwcwcwcw837378373773-order-draft',
            ];

            if (isset($endpoint_map[$status_slug])) {
                securepay_bridge_log("Order status changed to '{$status_slug}'. Triggering Site A hook: " . $endpoint_map[$status_slug]);
                request_call_to_a($order_id, $endpoint_map[$status_slug]);
            } else {
                 securepay_bridge_log("Order status changed to '{$status_slug}', but no corresponding Site A endpoint found.");
            }
        }

        // Hook into order status changes to notify Site A
        add_action('woocommerce_order_status_changed', function ($order_id, $old_status, $new_status) {
            securepay_bridge_log("WooCommerce order status changed for Order ID {$order_id} from '{$old_status}' to '{$new_status}'.");
            securepay_trigger_site_a_hook($order_id, $new_status);
        }, 10, 3);

        // Hook into thankyou page load to notify Site A about gateway processing
        add_action('woocommerce_thankyou', function ($order_id) {
            securepay_bridge_log("WooCommerce thankyou page loaded for Order ID {$order_id}. Triggering gateway processing hook on Site A.");
            request_call_to_a($order_id, 'wcwcwcwcwcw837378373773-order-gateway-processing');
        }, 10, 1);

        // Clear cookies when visiting the cart page
        add_action('template_redirect', function () {
            if (function_exists('is_cart') && is_cart()) {
                $past_time = time() - 3600; // Set expiry in the past
                setcookie('new_price', '', $past_time, '/');
                setcookie('myordernow', '', $past_time, '/');
                setcookie('myaffiliateurl', '', $past_time, '/');
                setcookie('order_key', '', $past_time, '/');
                securepay_bridge_log("Cleared SecurePay Bridge cookies on cart page.");
            }
        });

        // Redirect back to Site A after order received page
        add_action('template_redirect', 'redirect_after_order_received', 5);
        function redirect_after_order_received() {
            // Check if we are on the order-received endpoint and the order key is present
            if (function_exists('is_wc_endpoint_url') && is_wc_endpoint_url('order-received') && isset($_GET['key'])) {

                // **** START: License Check ****
                $license_status = get_option('securepay_license_status');
                if ($license_status !== 'valid') {
                    securepay_bridge_log("Redirecting to fallback due to invalid license status: " . $license_status . " on order-received page.");
                    // Redirect to a specific page on securepaybridge.net if license is invalid
                    wp_redirect('https://securepaybridge.net/license-validation/');
                    exit;
                }
                securepay_bridge_log("License status is valid. Proceeding with redirect logic.");
                // **** END: License Check ****

                $order_key = sanitize_text_field($_GET['key']);
                $order_id = wc_get_order_id_by_order_key($order_key);

                if (!$order_id) {
                     securepay_bridge_log("Invalid order key '{$order_key}' on thank you page. Cannot redirect back to Site A.");
                     return; // Exit if order ID cannot be found for the key
                }

                $order = wc_get_order($order_id);
                if (!$order) {
                     securepay_bridge_log("Could not retrieve order object for Order ID: " . $order_id . " on thank you page. Cannot redirect back to Site A.");
                     return; // Exit if order object cannot be retrieved
                }

                // Retrieve meta data saved during checkout
                $hook_url = $order->get_meta('hook_url', true);
                $external_order_id = $order->get_meta('external_order_id', true);
                $external_order_key = $order->get_meta('order_key', true);

                securepay_bridge_log("Retrieved meta data for Order ID {$order_id}: Hook URL='{$hook_url}', Ext Order ID='{$external_order_id}', Ext Order Key='{$external_order_key}'.");

                // Check if necessary meta data exists for redirection
                if (!empty($hook_url) && !empty($external_order_id) && !empty($external_order_key)) {
                    $custom_path = get_option('securepay_redirect_path', '');
                    $redirect_url = rtrim($hook_url, '/');

                    // Construct the final redirect URL based on custom path setting
                    if (!empty($custom_path)) {
                        $redirect_url .= '/' . ltrim(trim($custom_path), '/');
                        securepay_bridge_log("Using custom redirect path: " . $custom_path);
                    } else {
                        // Use Site A's default WooCommerce order received endpoint
                        $redirect_url .= "/checkout/order-received/{$external_order_id}/?key={$external_order_key}";
                        securepay_bridge_log("Using default WooCommerce redirect path on Site A.");
                    }

                    // Final validation before redirecting
                    if (filter_var($redirect_url, FILTER_VALIDATE_URL)) {
                        securepay_bridge_log("Redirecting back to Site A: " . $redirect_url);
                        wp_redirect($redirect_url);
                        exit; // Important to exit after redirect
                    } else {
                        securepay_bridge_log("Invalid final redirect URL generated for Order ID $order_id: " . $redirect_url);
                        // Optionally, display an error or redirect to a default page
                    }
                } else {
                     securepay_bridge_log("Missing redirection meta data for Order ID $order_id (Hook URL: " . (empty($hook_url) ? 'Empty' : 'Present') . ", Ext Order ID: " . (empty($external_order_id) ? 'Empty' : 'Present') . ", Ext Order Key: " . (empty($external_order_key) ? 'Empty' : 'Present') . "). Cannot redirect back to Site A.");
                }
            }
        }
        ?>
