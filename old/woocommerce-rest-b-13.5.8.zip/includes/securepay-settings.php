<?php
        /**
         * Handles settings and license check for SecurePay Bridge.
         */

        // Prevent direct access
        if ( ! defined( 'ABSPATH' ) ) {
            exit;
        }

        // Ensure this file path is correct relative to your plugin structure
        $plugin_dir_path = dirname(__FILE__);

        // Enqueue scripts and styles for settings page
        add_action('admin_enqueue_scripts', function ($hook) use ($plugin_dir_path) {
            if ($hook === 'woocommerce_page_securepay-bridge-settings') {
                // Use securepay_bridge_log for conditional logging
                securepay_bridge_log("Enqueuing scripts/styles for securepay-bridge-settings.");

                wp_enqueue_script('jquery');
                wp_enqueue_script('wc-enhanced-select'); // Provides Select2 functionality
                wp_enqueue_style('woocommerce_admin_styles'); // Provides Select2 styles + general WC admin styles

                // Enqueue custom admin CSS
                $main_plugin_file = dirname($plugin_dir_path) . '/woocommerce-rest-b.php';
                $css_url = plugins_url('includes/css/admin-style.css', $main_plugin_file);
                $css_physical_path = $plugin_dir_path . '/css/admin-style.css';

                if (file_exists($css_physical_path)) {
                     wp_enqueue_style(
                         'securepay-admin-style',
                         $css_url,
                         ['woocommerce_admin_styles'],
                         defined('SECUREPAY_BRIDGE_VERSION') ? SECUREPAY_BRIDGE_VERSION : '1.0'
                     );
                     securepay_bridge_log("Enqueued custom CSS 'securepay-admin-style'.");
                } else {
                    securepay_bridge_log('Admin CSS file not found at: ' . $css_physical_path);
                }

                // Enqueue custom admin JS for settings page interactions
                $js_url = plugins_url('includes/js/admin-settings.js', $main_plugin_file);
                $js_physical_path = $plugin_dir_path . '/js/admin-settings.js';
                 if (file_exists($js_physical_path)) {
                    wp_enqueue_script(
                        'securepay-admin-settings-js',
                        $js_url,
                        ['jquery', 'wc-enhanced-select'], // Depend on jQuery and WC Enhanced Select
                        defined('SECUREPAY_BRIDGE_VERSION') ? SECUREPAY_BRIDGE_VERSION : '1.0',
                        true // Load in footer
                    );
                     // Localize script to pass data like product list and nonce
                     $products_for_js = [];
                     // Fetch only necessary product data for performance
                     $products = wc_get_products(['limit' => -1, 'status' => 'publish', 'return' => 'objects']);
                     if (!empty($products)) {
                         foreach ($products as $product) {
                             $products_for_js[] = [
                                 'id' => $product->get_id(),
                                 'text' => esc_js($product->get_name() . ' (ID: ' . $product->get_id() . ')') // Use esc_js for safety
                             ];
                         }
                     }
                     wp_localize_script('securepay-admin-settings-js', 'securepay_settings_params', [
                         'ajax_url' => admin_url('admin-ajax.php'),
                         'nonce' => wp_create_nonce('securepay_settings_nonce'),
                         'products' => $products_for_js,
                         'text_select_product' => esc_js(__('Select product(s)...', 'securepay-bridge')), // Updated placeholder
                     ]);
                     securepay_bridge_log("Enqueued custom JS 'securepay-admin-settings-js' and localized script.");
                 } else {
                     securepay_bridge_log('[SecurePay Bridge] Admin JS file not found at: ' . $js_physical_path);
                 }

            }
        }, 20);

        // Add settings menu item under WooCommerce
        add_action('admin_menu', function () {
            add_submenu_page(
                'woocommerce', // Parent slug
                'SecurePay Bridge Settings', // Page title
                'SecurePay Bridge', // Menu title
                'manage_woocommerce', // Capability required
                'securepay-bridge-settings', // Menu slug
                'securepay_bridge_settings_page' // Callback function
            );
        });

        /**
         * Renders the admin settings page HTML.
         */
        function securepay_bridge_settings_page() {
            // Check user capabilities
            if (!current_user_can('manage_woocommerce')) {
                wp_die(__('You do not have sufficient permissions to access this page.'));
            }
            ?>
            <div class="wrap securepay-settings">
                <h1><span class="dashicons dashicons-admin-generic" style="font-size: 1.2em; margin-right: 5px;"></span> SecurePay Bridge Settings</h1>

                <?php settings_errors('securepay_settings'); // Show settings errors/notices ?>

                <p class="description">
                    Configure how redirected customers from Site A are handled on your store.<br>
                    Define product selection logic, redirect path, and manage your license.
                </p>

                <hr>

                <form method="post" action="options.php">
                    <?php
                    settings_fields('securepay_redirect_options'); // Output settings fields for the registered option group
                    do_settings_sections('securepay-bridge-settings'); // Output settings sections for the page slug
                    submit_button('💾 Save Settings'); // Display the save button
                    ?>
                </form>

                <?php // Inline JS for license check (keeping it simple here) ?>
                <script type="text/javascript">
                var ajaxurl = "<?php echo esc_url(admin_url('admin-ajax.php')); ?>";
                jQuery(document).ready(function($) {
                    // --- License Check Functionality ---
                    function checkLicense() {
                        var $button = $('#check-license-btn');
                        var licenseKey = $('input[name="securepay_license_key"]').val();
                        var licenseToken = $('input[name="securepay_license_token"]').val();
                        var $statusDiv = $('#license-status');
                        var $noticeDiv = $('#license-notice');
                        var nonce = $('#securepay_check_license_nonce_field').val();

                        if (!licenseKey || !licenseToken) {
                            $statusDiv.text('Missing Key/Token').css('color', 'orange');
                            $noticeDiv.html('<div class="license-check-result notice-warning">Please enter both License Key and Token.</div>');
                            return;
                        }

                        $statusDiv.text('Checking...').css('color', 'gray');
                        $noticeDiv.html('');
                        $button.prop('disabled', true);

                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'securepay_check_license',
                                license_key: licenseKey,
                                license_token: licenseToken,
                                _ajax_nonce: nonce
                            },
                            dataType: 'json',
                            success: function(response) {
                                var status, message, color, displayStatus, responseData;
                                if (response && typeof response === 'object') {
                                    responseData = response.data || {};
                                    status = responseData.status ? String(responseData.status).toLowerCase() : 'error';
                                    message = responseData.message || (response.success ? 'Success' : 'An unknown error occurred.');
                                    displayStatus = status.charAt(0).toUpperCase() + status.slice(1);

                                    if (responseData.license_type) {
                                        message += "<br><strong>Type:</strong> " + responseData.license_type;
                                        $('#stored-type').text(responseData.license_type);
                                    } else { $('#stored-type').text('N/A'); }
                                    if (responseData.expires_at) {
                                        message += "<br><strong>Expires:</strong> " + responseData.expires_at;
                                        $('#stored-expiry').text(responseData.expires_at);
                                    } else { $('#stored-expiry').text('N/A'); }

                                    color = (status === 'valid') ? 'green' : 'red';
                                    $('#stored-status').text(displayStatus);
                                } else {
                                    status = 'error'; displayStatus = 'Error';
                                    message = 'Received an unexpected response format from the server.';
                                    color = 'red';
                                    $('#stored-status').text('Error'); $('#stored-type').text('N/A'); $('#stored-expiry').text('N/A');
                                }
                                $statusDiv.text(displayStatus).css('color', color);
                                // *** MODIFIED LINE: Removed ">" before message ***
                                $noticeDiv.html('<div class="license-check-result notice-' + status + '">' + message + '</div>');
                            },
                            error: function(xhr, statusText, errorThrown) {
                                console.error("AJAX Error:", statusText, errorThrown, xhr.status, xhr.responseText);
                                $statusDiv.text('Error').css('color', 'red');
                                var errorMsg = 'An error occurred: ' + statusText + ' (' + xhr.status + ').';
                                $noticeDiv.html('<div class="license-check-result notice-error">' + errorMsg + ' Check console (F12).</div>');
                                $('#stored-status').text('Error'); $('#stored-type').text('N/A'); $('#stored-expiry').text('N/A');
                            },
                            complete: function() {
                                $button.prop('disabled', false);
                            }
                        });
                    }

                    $('#check-license-btn').on('click', function(e) {
                        e.preventDefault(); checkLicense();
                    });

                    var initialStatus = $('#stored-status').text().trim().toLowerCase();
                    var initialKey = $('input[name="securepay_license_key"]').val();
                    var initialToken = $('input[name="securepay_license_token"]').val();
                    if (initialKey && initialToken && (initialStatus === 'unknown' || initialStatus === '')) {
                        checkLicense();
                    } else if (!initialKey || !initialToken) {
                         $('#license-status').text('Missing Key/Token').css('color', 'orange');
                    } else {
                         var color = (initialStatus === 'valid') ? 'green' : 'red';
                         $('#license-status').text(initialStatus.charAt(0).toUpperCase() + initialStatus.slice(1)).css('color', color);
                    }
                    // --- End License Check ---

                    // Select2 initialization is now handled in admin-settings.js
                    // Basic check to ensure the function exists before calling
                    if (typeof $.fn.select2 === 'function') {
                         if ($('.securepay-select2').length > 0) {
                             // Basic init for non-dynamic selects, more complex logic in admin-settings.js
                             $('.securepay-select2:not(.securepay-select2-dynamic)').select2({ width: '100%', allowClear: true });
                             // console.log('Basic Select2 initialized for existing static .securepay-select2 elements.'); // Keep console logs minimal
                         }
                    } else {
                        console.error('Select2 function ($.fn.select2) is not defined on page load.');
                    }

                });
                </script>
            </div>
            <?php
        } // End securepay_bridge_settings_page function

        /**
         * Register settings, sections, and fields.
         */
        add_action('admin_init', function () {
            // Register Option Group
            $option_group = 'securepay_redirect_options';

            // Register Settings
            register_setting($option_group, 'securepay_redirect_path', ['sanitize_callback' => 'sanitize_text_field']);
            register_setting($option_group, 'securepay_product_selection_mode', ['sanitize_callback' => 'sanitize_key', 'default' => 'random']);
            register_setting($option_group, 'securepay_selected_products', ['sanitize_callback' => 'securepay_sanitize_array_of_ints']);
            register_setting($option_group, 'securepay_selected_categories', ['sanitize_callback' => 'securepay_sanitize_array_of_ints']);
            register_setting($option_group, 'securepay_price_conditions', ['sanitize_callback' => 'securepay_sanitize_price_conditions']); // Uses updated sanitizer
            register_setting($option_group, 'securepay_license_key', ['sanitize_callback' => 'sanitize_text_field']);
            register_setting($option_group, 'securepay_license_token', ['sanitize_callback' => 'sanitize_text_field']);
            register_setting($option_group, 'securepay_license_status', ['sanitize_callback' => 'sanitize_text_field']);
            register_setting($option_group, 'securepay_license_type', ['sanitize_callback' => 'sanitize_text_field']);
            register_setting($option_group, 'securepay_license_expires', ['sanitize_callback' => 'sanitize_text_field']);
            register_setting($option_group, 'securepay_enable_debug', ['sanitize_callback' => 'absint', 'default' => 0]);


            // Settings Sections
            $page_slug = 'securepay-bridge-settings';
            add_settings_section('securepay_product_logic_section', '🛒 Product Selection Logic', null, $page_slug);
            add_settings_section('securepay_redirect_path_section', '↪️ Redirect Path', null, $page_slug);
            add_settings_section('securepay_license_section', '🔑 License', null, $page_slug);
            add_settings_section('securepay_debug_section', '🐛 Debug Settings', null, $page_slug);


            // --- Product Logic Section Fields ---
            $section_id = 'securepay_product_logic_section';
            add_settings_field('securepay_product_selection_mode', '<label for="securepay_product_selection_mode"><strong style="font-size: 14px;">⚙️ Selection Method</strong></label>', 'securepay_field_selection_mode_cb', $page_slug, $section_id);
            add_settings_field('securepay_selected_products', '<label for="securepay_selected_products"><strong style="font-size: 14px;">📦 Specific Products</strong></label>', 'securepay_field_products_cb', $page_slug, $section_id, ['class' => 'securepay-setting-conditional securepay-setting-specific_product']);
            add_settings_field('securepay_selected_categories', '<label for="securepay_selected_categories"><strong style="font-size: 14px;">🗂️ Specific Categories</strong></label>', 'securepay_field_categories_cb', $page_slug, $section_id, ['class' => 'securepay-setting-conditional securepay-setting-specific_category']);
            add_settings_field('securepay_price_conditions', '<label for="securepay_price_conditions"><strong style="font-size: 14px;">💲 Price Range Conditions</strong></label>', 'securepay_field_price_conditions_cb', $page_slug, $section_id, ['class' => 'securepay-setting-conditional securepay-setting-conditional_price']);

            // --- Redirect Path Section Field ---
            $section_id = 'securepay_redirect_path_section';
            add_settings_field('securepay_redirect_path', '<label for="securepay_redirect_path"><strong style="font-size: 14px;">🔁 Custom Redirect Path</strong> <small>(optional)</small></label>', 'securepay_field_redirect_path_cb', $page_slug, $section_id);

            // --- License Section Fields ---
            $section_id = 'securepay_license_section';
            add_settings_field('securepay_license_key', '<label for="securepay_license_key"><strong style="font-size: 14px;">🔐 License Key</strong></label>', 'securepay_field_license_key_cb', $page_slug, $section_id);
            add_settings_field('securepay_license_token', '<label for="securepay_license_token"><strong style="font-size: 14px;">🧪 Token</strong></label>', 'securepay_field_license_token_cb', $page_slug, $section_id);
            add_settings_field('securepay_license_check', '<strong style="font-size: 14px;">🚦 License Status</strong>', 'securepay_field_license_check_cb', $page_slug, $section_id);

            // --- Debug Section Fields ---
            $section_id = 'securepay_debug_section';
            add_settings_field('securepay_enable_debug', '<label for="securepay_enable_debug"><strong style="font-size: 14px;">🐛 Enable Debug Logging</strong></label>', 'securepay_field_enable_debug_cb', $page_slug, $section_id);
        });

        /**
         * Callback functions for rendering settings fields.
         */

        // Callback for Selection Mode Radio Buttons
        function securepay_field_selection_mode_cb() {
            $current_mode = get_option('securepay_product_selection_mode', 'random');
            $modes = [
                'random' => __('Random Product (Default)', 'securepay-bridge'),
                'conditional_price' => __('Conditional based on Price Range', 'securepay-bridge'),
                'specific_product' => __('Specific Product(s)', 'securepay-bridge'),
                'specific_category' => __('Specific Category(ies)', 'securepay-bridge'),
            ];
            echo '<fieldset>';
            foreach ($modes as $mode_key => $mode_label) {
                echo '<label style="display: block; margin-bottom: 5px;">';
                echo '<input type="radio" name="securepay_product_selection_mode" value="' . esc_attr($mode_key) . '" ' . checked($current_mode, $mode_key, false) . '/> ';
                echo esc_html($mode_label);
                echo '</label>';
            }
            echo '<p class="description" style="margin-top: 5px;">' . __('Select how the product added to the cart is determined.', 'securepay-bridge') . '</p>';
            echo '</fieldset>';
        }

        // Callback for Specific Products
        function securepay_field_products_cb($args) {
            $selected_products = get_option('securepay_selected_products', []);
            $products = wc_get_products(['status' => 'publish', 'limit' => -1, 'orderby'=> 'title', 'order' => 'ASC', 'return' => 'objects']);
            $row_class = isset($args['class']) ? esc_attr($args['class']) : '';
            echo '<tr valign="top" class="' . $row_class . '"><th></th><td>'; // Wrap in TD for proper table structure if needed
            echo "<p style='margin-top: 0;'>Choose specific products. If multiple are selected, one will be chosen randomly.</p>";
            if (!empty($products)) {
                echo "<select id='securepay_selected_products' name='securepay_selected_products[]' multiple class='securepay-select2' style='width:100%; max-width: 400px;'>";
                foreach ($products as $product) {
                    $is_selected = is_array($selected_products) && in_array($product->get_id(), $selected_products);
                    echo "<option value='" . esc_attr($product->get_id()) . "' " . selected($is_selected, true, false) . ">" . esc_html($product->get_name()) . " (ID: " . esc_html($product->get_id()) . ")</option>";
                }
                echo "</select>";
            } else { echo "<p><em style='color: #a00;'>No published products found.</em></p>"; }
            echo '</td></tr>'; // Close wrapper
        }

        // Callback for Specific Categories
        function securepay_field_categories_cb($args) {
            $selected_cats = get_option('securepay_selected_categories', []);
            $categories = get_terms(['taxonomy' => 'product_cat', 'hide_empty' => true, 'orderby' => 'name', 'order' => 'ASC']);
            $row_class = isset($args['class']) ? esc_attr($args['class']) : '';
             echo '<tr valign="top" class="' . $row_class . '"><th></th><td>'; // Wrap in TD
            echo "<p style='margin-top: 0;'>Choose categories. A random product from the selected categories will be added.</p>";
            if (!empty($categories) && !is_wp_error($categories)) {
                echo "<select id='securepay_selected_categories' name='securepay_selected_categories[]' multiple class='securepay-select2' style='width:100%; max-width: 400px;'>";
                foreach ($categories as $cat) {
                    $is_selected = is_array($selected_cats) && in_array($cat->term_id, $selected_cats);
                    echo "<option value='" . esc_attr($cat->term_id) . "' " . selected($is_selected, true, false) . ">" . esc_html($cat->name) . "</option>";
                }
                echo "</select>";
            } else { echo "<p><em style='color: #a00;'>No categories with published products found.</em></p>"; }
             echo '</td></tr>'; // Close wrapper
        }

        // Callback for Price Range Conditions
        function securepay_field_price_conditions_cb($args) {
            $conditions = get_option('securepay_price_conditions', []);
            $row_class = isset($args['class']) ? esc_attr($args['class']) : '';
             echo '<tr valign="top" class="' . $row_class . '"><th></th><td>'; // Wrap in TD
            echo '<div id="securepay-price-conditions-wrapper">';
            echo '<p class="description" style="margin-bottom: 10px;">' . __('Define price ranges to add specific products based on the incoming `total_amount`. If the amount falls within a range, one of the selected products for that range will be added randomly. Rules are checked in order; the first match is used.', 'securepay-bridge') . '</p>';
            echo '<table class="wp-list-table widefat striped" style="max-width: 800px;">';
            echo '<thead><tr><th style="width: 15%;">' . __('Min Price', 'securepay-bridge') . '</th><th style="width: 15%;">' . __('Max Price', 'securepay-bridge') . '</th><th style="width: 50%;">' . __('Product(s) to Add', 'securepay-bridge') . '</th><th style="width: 20%;">' . __('Action', 'securepay-bridge') . '</th></tr></thead>';
            echo '<tbody id="securepay-price-conditions-tbody">';
            // Condition Row Template (for JS) - Hidden
            echo '<tr id="securepay-condition-template" style="display:none;">';
            echo '<td><input type="number" step="0.01" min="0" name="securepay_price_conditions[__INDEX__][min_amount]" class="securepay-condition-min-amount short" placeholder="e.g., 50.00" /></td>';
            echo '<td><input type="number" step="0.01" min="0" name="securepay_price_conditions[__INDEX__][max_amount]" class="securepay-condition-max-amount short" placeholder="e.g., 100.00" /></td>';
            echo '<td><select name="securepay_price_conditions[__INDEX__][product_ids][]" multiple class="securepay-condition-product securepay-select2-dynamic" data-placeholder="' . esc_attr__('Select product(s)...', 'securepay-bridge') . '" style="width: 100%;"></select></td>';
            echo '<td><button type="button" class="button button-secondary securepay-remove-condition">Remove</button></td>';
            echo '</tr>';
            // Existing Conditions
            if (!empty($conditions) && is_array($conditions)) {
                $index = 0;
                foreach ($conditions as $condition) {
                    $min_amount = isset($condition['min_amount']) ? $condition['min_amount'] : '';
                    $max_amount = isset($condition['max_amount']) ? $condition['max_amount'] : '';
                    $product_ids = isset($condition['product_ids']) && is_array($condition['product_ids']) ? $condition['product_ids'] : [];
                    echo '<tr>';
                    echo '<td><input type="number" step="0.01" min="0" name="securepay_price_conditions[' . $index . '][min_amount]" value="' . esc_attr($min_amount) . '" class="securepay-condition-min-amount short" placeholder="e.g., 50.00" /></td>';
                    echo '<td><input type="number" step="0.01" min="0" name="securepay_price_conditions[' . $index . '][max_amount]" value="' . esc_attr($max_amount) . '" class="securepay-condition-max-amount short" placeholder="e.g., 100.00" /></td>';
                    echo '<td><select name="securepay_price_conditions[' . $index . '][product_ids][]" multiple class="securepay-condition-product securepay-select2" data-placeholder="' . esc_attr__('Select product(s)...', 'securepay-bridge') . '" style="width: 100%;">';
                    $products = wc_get_products(['limit' => -1, 'status' => 'publish', 'return' => 'objects']);
                     if (!empty($products)) {
                         foreach ($products as $product) {
                             $is_selected = in_array($product->get_id(), $product_ids);
                             echo '<option value="' . esc_attr($product->get_id()) . '" ' . selected($is_selected, true, false) . '>' . esc_html($product->get_name()) . ' (ID: ' . esc_html($product->get_id()) . ')</option>';
                         }
                     }
                    echo '</select></td>';
                    echo '<td><button type="button" class="button button-secondary securepay-remove-condition">Remove</button></td>';
                    echo '</tr>';
                    $index++;
                }
            }
            echo '</tbody></table>';
            echo '<button type="button" id="securepay-add-condition" class="button button-secondary" style="margin-top: 10px;">+ Add Price Range Condition</button>';
            echo '</div>'; // End wrapper
             echo '</td></tr>'; // Close wrapper
        }

        // Callbacks for Redirect Path & License
        function securepay_field_redirect_path_cb() {
            $value = get_option('securepay_redirect_path', '');
             echo '<tr valign="top"><th></th><td>'; // Wrap in TD
            echo "<input type='text' id='securepay_redirect_path' name='securepay_redirect_path' value='" . esc_attr($value) . "' class='regular-text' placeholder='/custom-thank-you' />";
            echo "<p class='description' style='margin-top:5px;'>Set a custom thank-you path relative to Site A's domain (e.g., /order-complete). Leave blank for WooCommerce default path on Site A.</p>";
             echo '</td></tr>'; // Close wrapper
        }

        function securepay_field_license_key_cb() {
            $value = get_option('securepay_license_key', '');
             echo '<tr valign="top"><th></th><td>'; // Wrap in TD
            echo "<input type='password' id='securepay_license_key' name='securepay_license_key' value='" . esc_attr($value) . "' class='regular-text' placeholder='Enter your license key' autocomplete='off' required />";
             echo '</td></tr>'; // Close wrapper
        }

        function securepay_field_license_token_cb() {
            $value = get_option('securepay_license_token', '');
             echo '<tr valign="top"><th></th><td>'; // Wrap in TD
            echo "<input type='password' id='securepay_license_token' name='securepay_license_token' value='" . esc_attr($value) . "' class='regular-text' placeholder='Enter your token' autocomplete='off' required />";
             echo '</td></tr>'; // Close wrapper
        }

        function securepay_field_license_check_cb() {
             echo '<tr valign="top"><th></th><td>'; // Wrap in TD
            echo "<div style='display: flex; align-items: center; gap: 10px; flex-wrap: wrap;'>";
            echo "<div id='license-status' style='font-weight: bold; color: gray; min-width: 80px; text-align: left;'>Checking...</div>";
            echo "<button type='button' id='check-license-btn' class='button button-secondary'>Check License Now</button>";
            wp_nonce_field('securepay_check_license_nonce', 'securepay_check_license_nonce_field', false);
            echo "</div>";
            echo "<div id='license-notice' style='margin-top: 10px; padding: 8px; border-radius: 4px; border: 1px solid transparent;'></div>";

            $stored_status  = get_option('securepay_license_status', 'unknown');
            $stored_type    = get_option('securepay_license_type');
            $stored_expiry  = get_option('securepay_license_expires');
            echo "<p style='margin-top:15px; font-size: 13px; color: #555; border-top: 1px dashed #ccc; padding-top: 10px;'>";
            echo "<strong>Stored License Status:</strong> <span id='stored-status'>" . esc_html(ucfirst($stored_status)) . "</span><br>";
            echo "<strong>License Type:</strong> <span id='stored-type'>" . esc_html($stored_type ?: 'N/A') . "</span><br>";
            echo "<strong>Expires At:</strong> <span id='stored-expiry'>" . esc_html($stored_expiry ?: 'N/A') . "</span>";
             if ($stored_status === 'unknown' || empty($stored_status)) { echo "<br><em>Status not checked or saved yet.</em>"; }
            echo "</p>";
             echo '</td></tr>'; // Close wrapper
        }

        // Callback for Enable Debug Logging Field
        function securepay_field_enable_debug_cb() {
            $debug_enabled = get_option('securepay_enable_debug', 0);
             echo '<tr valign="top"><th></th><td>'; // Wrap in TD
            echo '<label>';
            echo '<input type="checkbox" id="securepay_enable_debug" name="securepay_enable_debug" value="1" ' . checked(1, $debug_enabled, false) . '/> ';
            echo __('Enable logging of debug messages to the PHP error log.', 'securepay-bridge');
            echo '</label>';
            echo "<p class='description' style='margin-top:5px;'>Debug messages will be written to your server's PHP error log file. This should be disabled on production sites unless troubleshooting.</p>";
             echo '</td></tr>'; // Close wrapper
        }


        // AJAX handler for license check
        add_action('wp_ajax_securepay_check_license', 'securepay_check_license');
        function securepay_check_license() {
            securepay_bridge_log("AJAX: securepay_check_license triggered.");

            if (!check_ajax_referer('securepay_check_license_nonce', '_ajax_nonce', false)) {
                securepay_bridge_log("AJAX: securepay_check_license - Nonce check failed.");
                wp_send_json_error(['status' => 'nonce_error', 'message' => __('Security check failed.', 'securepay-bridge')], 403);
            }
            if (!current_user_can('manage_woocommerce')) {
                 securepay_bridge_log("AJAX: securepay_check_license - Permission denied.");
                 wp_send_json_error(['status' => 'permission_error', 'message' => __('Permission denied.', 'securepay-bridge')], 403);
            }
            $license_key   = isset($_POST['license_key']) ? sanitize_text_field(wp_unslash($_POST['license_key'])) : '';
            $license_token = isset($_POST['license_token']) ? sanitize_text_field(wp_unslash($_POST['license_token'])) : '';
            $site_url = site_url();
            $domain = preg_replace( '#^https?://(www\.)?#i', '', $site_url );
            $domain = strtolower(rtrim($domain, '/'));

            if (empty($license_key) || empty($license_token)) {
                securepay_bridge_log("AJAX: securepay_check_license - Missing license key or token.");
                wp_send_json_error(['status' => 'missing_data', 'message' => __('License key and token are required.', 'securepay-bridge')], 400);
            }

            $request_data = ['domain' => $domain, 'key' => $license_key, 'token' => $license_token];
            securepay_bridge_log("AJAX: securepay_check_license - Data Sent to API: " . print_r(array_merge($request_data, ['token' => '***']), true));

            $api_url = 'https://auth.securepaybridge.net/license-check.php';
            $response = wp_remote_post($api_url, [
                'method' => 'POST', 'timeout' => 25, 'redirection' => 5, 'httpversion' => '1.1',
                'sslverify' => true, 'body' => $request_data,
                'headers' => [
                    'Accept' => 'application/json',
                    'User-Agent' => 'SecurePayBridgeWP/' . (defined('SECUREPAY_BRIDGE_VERSION') ? SECUREPAY_BRIDGE_VERSION : '1.0') . '; ' . home_url(),
                    'Content-Type' => 'application/x-www-form-urlencoded',
                ], 'cookies' => []
            ]);

            if (is_wp_error($response)) {
                $error_message = $response->get_error_message();
                securepay_bridge_log("AJAX: securepay_check_license - WP Error calling license server: " . $error_message);
                wp_send_json_error(['status' => 'connection_error', 'message' => __('Error connecting to the license server.', 'securepay-bridge') . ' (' . esc_html($error_message) . ')'], 500);
            }

            $http_code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            securepay_bridge_log("AJAX: securepay_check_license - Raw Response (HTTP $http_code): " . substr($body, 0, 500));

            if (empty($body)) {
                 securepay_bridge_log("AJAX: securepay_check_license - Received empty response from license server (HTTP: $http_code).");
                 wp_send_json_error(['status' => 'empty_response', 'message' => __('Received an empty response from the license server.', 'securepay-bridge') . " (HTTP: $http_code)"], 502);
            }

            $data = json_decode($body, true);

            if ($data === null || !isset($data['status'])) {
                $is_html = strip_tags($body) !== $body;
                $error_detail = $is_html ? 'Non-JSON response received.' : 'Invalid JSON or missing status.';
                securepay_bridge_log("AJAX: securepay_check_license - Invalid response format. $error_detail HTTP Code: " . $http_code . " Body: " . substr($body, 0, 500));
                wp_send_json_error(['status' => 'invalid_response_format', 'message' => __('Received an invalid response format from the license server.', 'securepay-bridge') . " ($error_detail)"], 502);
            }
            securepay_bridge_log("AJAX: securepay_check_license - Decoded Data: " . print_r($data, true));

            $license_server_status = isset($data['status']) ? strtolower(trim($data['status'])) : 'unknown';
            $license_message = isset($data['message']) ? sanitize_text_field($data['message']) : 'No message received.';

            // Update options based on server response
            update_option('securepay_license_status', $license_server_status);
            if ($license_server_status === 'valid') {
                update_option('securepay_license_type', isset($data['license_type']) ? sanitize_text_field($data['license_type']) : null);
                update_option('securepay_license_expires', isset($data['expires_at']) ? sanitize_text_field($data['expires_at']) : null);
                securepay_bridge_log("AJAX: securepay_check_license - License is valid. Status: $license_server_status, Type: " . get_option('securepay_license_type') . ", Expires: " . get_option('securepay_license_expires'));
            } else {
                delete_option('securepay_license_type');
                delete_option('securepay_license_expires');
                securepay_bridge_log("AJAX: securepay_check_license - License is NOT valid. Status: $license_server_status. Cleared type and expiry options.");
            }

            // Prepare response data for the client-side JS
            $response_data_to_client = [
                'status' => $license_server_status, 'message' => $license_message,
                'license_type' => get_option('securepay_license_type'),
                'expires_at' => get_option('securepay_license_expires'),
            ];

            // Send appropriate JSON response
            if ($http_code >= 200 && $http_code < 300 && $license_server_status === 'valid') {
                 wp_send_json_success($response_data_to_client);
            } else {
                 $client_http_code = ($http_code >= 400) ? $http_code : 400;
                 securepay_bridge_log("AJAX: securepay_check_license - License check failed. Status '$license_server_status'. HTTP Code from Server: " . $http_code);
                 wp_send_json_error($response_data_to_client, $client_http_code);
            }
        }


        /**
         * Sanitize array of integers.
         */
        function securepay_sanitize_array_of_ints($input) {
            if (!is_array($input)) {
                securepay_bridge_log("Sanitization: securepay_sanitize_array_of_ints received non-array input.");
                return [];
            }
            $input = array_map('absint', $input);
            $sanitized = array_filter($input, function($value) { return $value > 0; });
            securepay_bridge_log("Sanitization: securepay_sanitize_array_of_ints - Input: " . print_r($input, true) . " Output: " . print_r($sanitized, true));
            return $sanitized;
        }

        /**
         * Sanitize price range conditions array.
         */
        function securepay_sanitize_price_conditions($input) {
            $sanitized_conditions = [];
            if (!is_array($input)) {
                securepay_bridge_log("Sanitization: securepay_sanitize_price_conditions received non-array input.");
                return $sanitized_conditions;
            }

            foreach ($input as $condition) {
                if (!is_array($condition)) {
                    securepay_bridge_log("Sanitization: securepay_sanitize_price_conditions skipped non-array condition element: " . print_r($condition, true));
                    continue;
                }

                $min_amount = isset($condition['min_amount']) && is_numeric($condition['min_amount']) ? max(0, floatval($condition['min_amount'])) : null;
                $max_amount = isset($condition['max_amount']) && is_numeric($condition['max_amount']) ? max(0, floatval($condition['max_amount'])) : null;
                $product_ids = isset($condition['product_ids']) && is_array($condition['product_ids']) ? securepay_sanitize_array_of_ints($condition['product_ids']) : [];

                if (($min_amount !== null || $max_amount !== null) && !empty($product_ids)) {
                    if ($min_amount !== null && $max_amount !== null && $min_amount > $max_amount) {
                        securepay_bridge_log("Sanitization skipped invalid price range (min > max): " . print_r($condition, true));
                        continue;
                    }

                    $valid_product_ids = [];
                    foreach ($product_ids as $pid) {
                        $product = wc_get_product($pid);
                        if ($product && $product->exists() && $product->is_purchasable() && $product->get_status() === 'publish') {
                            $valid_product_ids[] = $pid;
                        } else {
                            securepay_bridge_log("Sanitization removed invalid/non-purchasable product ID ($pid) from price condition.");
                        }
                    }

                    if (!empty($valid_product_ids)) {
                        $sanitized_conditions[] = [
                            'min_amount' => $min_amount,
                            'max_amount' => $max_amount,
                            'product_ids' => $valid_product_ids,
                        ];
                        securepay_bridge_log("Sanitization added valid price condition: " . print_r(['min_amount' => $min_amount, 'max_amount' => $max_amount, 'product_ids' => $valid_product_ids], true));
                    } else {
                         securepay_bridge_log("Sanitization removed price condition due to no valid products remaining: " . print_r($condition, true));
                    }

                } else {
                     securepay_bridge_log("Sanitization removed invalid/incomplete price condition (missing min/max or products): " . print_r($condition, true));
                }
            }
            securepay_bridge_log("Sanitization: securepay_sanitize_price_conditions - Final Output: " . print_r($sanitized_conditions, true));
            return $sanitized_conditions;
        }


        // Admin notice for license status
        add_action('admin_notices', function () {
            $screen = get_current_screen();
            if ($screen && $screen->id === 'woocommerce_page_securepay-bridge-settings') {
                $license_key = get_option('securepay_license_key');
                $license_token = get_option('securepay_license_token');
                if (empty($license_key) || empty($license_token)) {
                    echo '<div class="notice notice-warning is-dismissible"><p><strong>SecurePay Bridge:</strong> ' . __('Please enter your License Key and Token.', 'securepay-bridge') . '</p></div>';
                } else {
                    $stored_status = get_option('securepay_license_status');
                    if ($stored_status && $stored_status !== 'valid' && $stored_status !== 'unknown') {
                         echo '<div class="notice notice-error is-dismissible"><p><strong>SecurePay Bridge:</strong> ' . sprintf(__('License is not active (Status: %s).', 'securepay-bridge'), '<strong>' . esc_html(ucfirst($stored_status)) . '</strong>') . '</p></div>';
                    } elseif ($stored_status === 'unknown') {
                         echo '<div class="notice notice-info is-dismissible"><p><strong>SecurePay Bridge:</strong> ' . __('License status is unknown. Click "Check License Now".', 'securepay-bridge') . '</p></div>';
                    }
                }
            }
        });

        ?>
