<?php
        /*
        Plugin Name: SecurePay Bridge – Low Risk Site
        Plugin URI: https://securepaybridge.net
        Description: Seamlessly receive WooCommerce order data from a high-risk source and auto-initiate checkout in this low-risk store for secure and smooth payment processing.
        Version: 13.5.8
        Author: SecurePay Bridge
        Author URI: https://securepaybridge.net
        */

        /**
         * @package Woocomerce-Rest-B
         */

        if (!defined('ABSPATH')) exit; // Exit if accessed directly

        // Define plugin version constant (if not already defined)
        if (!defined('SECUREPAY_BRIDGE_VERSION')) {
            define('SECUREPAY_BRIDGE_VERSION', '13.5.8'); // Match the version in the header
        }

        // Load plugin settings
        require_once plugin_dir_path(__FILE__) . 'includes/securepay-settings.php';

        // Include the plugin updater class
        require_once plugin_dir_path(__FILE__) . 'includes/plugin-updater.php';

        // Instantiate the updater class
        $securepay_bridge_updater = new SecurePay_Bridge_Updater(
            __FILE__,
            'https://auth.securepaybridge.net/update-check.php',
            plugin_basename(__FILE__),
            SECUREPAY_BRIDGE_VERSION
        );

        function securepay_bridge_log($message) {
            $debug_enabled = get_option('securepay_enable_debug', 0);
            if ($debug_enabled) {
                error_log("[SecurePay Bridge v" . SECUREPAY_BRIDGE_VERSION . "] " . $message);
            }
        }

        // Handle incoming parameters and set cookies (No changes here)
        if (isset($_GET['total_amount'])) {
            $total_amount = floatval($_GET['total_amount']);
            $myordernow = isset($_GET['myordernow']) ? sanitize_text_field($_GET['myordernow']) : '';
            $myaffiliateurl = isset($_GET['myaffiliateurl']) ? urldecode(sanitize_url($_GET['myaffiliateurl'])) : '';
            $order_key = isset($_GET['order_key']) ? sanitize_text_field($_GET['order_key']) : '';

            securepay_bridge_log("Clearing previous SecurePay cookies before setting new ones.");
            $past_time = time() - 3600;
            setcookie('new_price', '', $past_time, '/');
            setcookie('myordernow', '', $past_time, '/');
            setcookie('myaffiliateurl', '', $past_time, '/');
            setcookie('order_key', '', $past_time, '/');

            setcookie('new_price', $total_amount, 0, '/');
            setcookie('myordernow', $myordernow, 0, '/');
            setcookie('myaffiliateurl', $myaffiliateurl, 0, '/');
            if (!empty($order_key)) {
                setcookie('order_key', $order_key, 0, '/');
            }
            securepay_bridge_log("Incoming parameters detected from Site A. Setting cookies: new_price={$total_amount}, myordernow={$myordernow}, myaffiliateurl={$myaffiliateurl}, order_key={$order_key}");

            add_filter('query_vars', function($vars) {
                $vars[] = 'total_amount'; $vars[] = 'billing_first_name'; $vars[] = 'billing_last_name';
                $vars[] = 'billing_email'; $vars[] = 'billing_company'; $vars[] = 'billing_address_1';
                $vars[] = 'billing_address_2'; $vars[] = 'billing_city'; $vars[] = 'billing_state';
                $vars[] = 'billing_postcode'; $vars[] = 'billing_country'; $vars[] = 'billing_phone';
                $vars[] = 'currency'; $vars[] = 'myordernow'; $vars[] = 'myaffiliateurl'; $vars[] = 'order_key';
                return $vars;
            });
        }

        // Handle cart/checkout initiation and cleanup
        add_action('template_redirect', function () {

            // *** START: Cleanup on direct homepage visit with lingering cookies ***
            // Check if it's the homepage, A->B trigger is NOT present, but our cookies ARE present
            if ( function_exists('is_front_page') && is_front_page() &&
                 !isset($_GET['total_amount']) &&
                 (isset($_COOKIE['new_price']) || isset($_COOKIE['myordernow']) || isset($_COOKIE['myaffiliateurl']) || isset($_COOKIE['order_key']))
               )
            {
                securepay_bridge_log("Homepage visit detected with lingering SecurePay cookies and no A->B trigger. Cleaning up state.");

                // Ensure WooCommerce and Cart are available before clearing
                if (function_exists('WC') && WC()->cart && !WC()->cart->is_empty()) {
                    WC()->cart->empty_cart();
                    securepay_bridge_log("Homepage Cleanup: Cart emptied.");
                } else {
                    // Log even if cart is already empty or WC not ready
                    securepay_bridge_log("Homepage Cleanup: Cart already empty or WC/Cart not available.");
                }

                // Clear the cookies
                $past_time = time() - 3600;
                setcookie('new_price', '', $past_time, '/');
                setcookie('myordernow', '', $past_time, '/');
                setcookie('myaffiliateurl', '', $past_time, '/');
                setcookie('order_key', '', $past_time, '/');
                securepay_bridge_log("Homepage Cleanup: SecurePay cookies cleared.");

                // Optional: Clear the session currency as well if it might linger
                if (function_exists('WC') && WC()->session && WC()->session->get('client_currency')) {
                     WC()->session->__unset('client_currency');
                     securepay_bridge_log("Homepage Cleanup: Client currency session cleared.");
                }

                // After cleanup, exit this function to allow normal homepage loading
                return;
            }
            // *** END: Cleanup on direct homepage visit ***


            // *** START: A->B Checkout Initiation ***
            // PRIMARY TRIGGER: Only proceed if total_amount is explicitly in the GET request
            if (!isset($_GET['total_amount'])) {
                // If total_amount is NOT in the GET request, and it wasn't the homepage cleanup case above, do nothing.
                return;
            }

            // --- Proceed with A->B logic ---
            $incoming_total_amount = floatval($_GET['total_amount']);
            securepay_bridge_log("A->B Trigger: Incoming total_amount from GET: " . $incoming_total_amount);

            // Don't run if already on checkout page (prevents redirect loops)
            if (is_checkout()) {
                securepay_bridge_log("A->B Trigger: Already on checkout page. Exiting.");
                return;
            }

            // Ensure WooCommerce and Cart are available
            if (!function_exists('WC') || !WC()->cart) {
                securepay_bridge_log("A->B Trigger: WooCommerce or Cart not available. Exiting.");
                return;
            }

            securepay_bridge_log("A->B Trigger: Starting cart setup.");
            WC()->cart->empty_cart(); // Empty cart for the new A->B session
            securepay_bridge_log("A->B Trigger: Cart emptied.");

            $product_id_to_add = null;
            $selection_mode = get_option('securepay_product_selection_mode', 'random');
            securepay_bridge_log("A->B Trigger: Product Selection Mode: " . $selection_mode);
            securepay_bridge_log("A->B Trigger: Incoming Total Amount for Selection Logic: " . $incoming_total_amount);

            // --- Product Selection Logic (No changes here) ---
            if ($selection_mode === 'conditional_price') {
                $price_conditions = get_option('securepay_price_conditions', []);
                securepay_bridge_log("A->B Trigger: Evaluating Price Conditions: " . print_r($price_conditions, true));
                if (!empty($price_conditions) && is_array($price_conditions)) {
                    foreach ($price_conditions as $condition) {
                        $min_amount = isset($condition['min_amount']) && is_numeric($condition['min_amount']) ? floatval($condition['min_amount']) : null;
                        $max_amount = isset($condition['max_amount']) && is_numeric($condition['max_amount']) ? floatval($condition['max_amount']) : null;
                        $product_ids = isset($condition['product_ids']) && is_array($condition['product_ids']) ? $condition['product_ids'] : [];
                        $match = true;
                        if ($min_amount !== null && $incoming_total_amount < $min_amount) { $match = false; }
                        if ($match && $max_amount !== null && $incoming_total_amount > $max_amount) { $match = false; }
                        if ($match && !empty($product_ids)) {
                            $chosen_product_id = $product_ids[array_rand($product_ids)];
                            $product_id_to_add = $chosen_product_id;
                            securepay_bridge_log("A->B Trigger: Price Condition Matched: Min=" . ($min_amount ?? 'N/A') . ", Max=" . ($max_amount ?? 'N/A') . ". Randomly selected Product ID: " . $product_id_to_add . " from [" . implode(',', $product_ids) . "]");
                            break;
                        } else { securepay_bridge_log("A->B Trigger: Condition did not match or had no valid products: Min=" . ($min_amount ?? 'N/A') . ", Max=" . ($max_amount ?? 'N/A') . ", Product IDs: " . (empty($product_ids) ? 'None' : implode(',', $product_ids))); }
                    }
                } else { securepay_bridge_log("A->B Trigger: No price conditions configured."); }
                 if ($product_id_to_add === null) { securepay_bridge_log("A->B Trigger: No price condition matched. Falling back to default random selection."); }
            } elseif ($selection_mode === 'specific_product') {
                $selected_products = get_option('securepay_selected_products', []);
                if (!empty($selected_products)) {
                    $product_id_to_add = $selected_products[array_rand($selected_products)];
                    securepay_bridge_log("A->B Trigger: Specific Product Mode: Adding random product from selected list. Chosen ID: " . $product_id_to_add);
                } else { securepay_bridge_log("A->B Trigger: Specific Product Mode selected but no products specified. Falling back."); }
            } elseif ($selection_mode === 'specific_category') {
                $selected_categories = get_option('securepay_selected_categories', []);
                if (!empty($selected_categories)) {
                    $args = ['status' => 'publish', 'limit' => -1, 'return' => 'ids', 'tax_query' => [['taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $selected_categories]]];
                    $products_in_cats = wc_get_products($args);
                    if (!empty($products_in_cats)) {
                        $product_id_to_add = $products_in_cats[array_rand($products_in_cats)];
                        securepay_bridge_log("A->B Trigger: Specific Category Mode: Adding random product from selected categories. Chosen ID: " . $product_id_to_add);
                    } else { securepay_bridge_log("A->B Trigger: Specific Category Mode: No published products found in selected categories. Falling back."); }
                } else { securepay_bridge_log("A->B Trigger: Specific Category Mode selected but no categories specified. Falling back."); }
            }
            // --- Fallback / Default Random Selection (No changes here) ---
            if ($product_id_to_add === null) {
                if ($selection_mode !== 'random') { securepay_bridge_log("A->B Trigger: Fallback Triggered: Mode '{$selection_mode}' failed. Using default random."); }
                else { securepay_bridge_log("A->B Trigger: Random Mode (Default): Selecting random product."); }
                $all_products_args = ['post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids'];
                $all_products = get_posts($all_products_args);
                if (!empty($all_products)) {
                    $product_id_to_add = $all_products[array_rand($all_products)];
                    securepay_bridge_log("A->B Trigger: Default Random Selection: Chosen ID: " . $product_id_to_add);
                } else { securepay_bridge_log("CRITICAL: No published products found for default selection."); wp_die('Error: No products available.'); }
            }
            // --- Add product to cart (No changes here) ---
            if ($product_id_to_add) {
                $result = WC()->cart->add_to_cart($product_id_to_add, 1);
                if (!$result) { securepay_bridge_log("A->B Trigger: Failed to add product ID {$product_id_to_add} to cart."); wp_die('Error adding product to cart.'); }
                else { securepay_bridge_log("A->B Trigger: Successfully added product ID {$product_id_to_add} to cart."); }
            } else { securepay_bridge_log("CRITICAL ERROR: Could not determine product ID."); wp_die('Error preparing cart.'); }
            // --- Populate customer billing details (No changes here) ---
            $fields = ['billing_first_name', 'billing_last_name', 'billing_email', 'billing_company', 'billing_address_1', 'billing_address_2', 'billing_city', 'billing_state', 'billing_postcode', 'billing_country', 'billing_phone'];
            foreach ($fields as $field) {
                if (isset($_GET[$field])) {
                    $value = sanitize_text_field(urldecode($_GET[$field])); $method = 'set_' . $field;
                    if (method_exists(WC()->customer, $method)) { WC()->customer->$method($value); securepay_bridge_log("A->B Trigger: Set customer field '{$field}' to '{$value}'."); }
                    else { securepay_bridge_log("A->B Trigger: Method '{$method}' does not exist."); }
                }
            }
            // --- Set currency (No changes here) ---
            if (isset($_GET['currency'])) {
                $currency_code = sanitize_text_field($_GET['currency']);
                if (array_key_exists($currency_code, get_woocommerce_currencies())) { WC()->session->set('client_currency', $currency_code); securepay_bridge_log("A->B Trigger: Set client currency session to: " . $currency_code); }
                else { securepay_bridge_log("A->B Trigger: Invalid currency code: " . $currency_code); }
            }
            // --- Redirect to checkout (No changes here) ---
            if (!is_checkout()) { $checkout_url = wc_get_checkout_url(); securepay_bridge_log("A->B Trigger: Redirecting to checkout: " . $checkout_url); wp_safe_redirect($checkout_url); exit; }
            // *** END: A->B Checkout Initiation ***
        });


        // Action to potentially change currency based on session before calculations (No changes here)
        add_action('woocommerce_before_calculate_totals', function ($cart) {
            if (is_admin() && !defined('DOING_AJAX')) return;
            $client_currency = WC()->session->get('client_currency');
            if ($client_currency && $client_currency !== get_woocommerce_currency()) {
                add_filter('woocommerce_currency', function($currency) use ($client_currency) { securepay_bridge_log("Applying temporary currency filter: " . $client_currency); return $client_currency; }, 9999);
                securepay_bridge_log("Temporarily setting currency via session for calculation: " . $client_currency);
            }
            if (isset($_COOKIE['new_price'])) {
                $new_price = floatval($_COOKIE['new_price']);
                securepay_bridge_log("Applying custom price from cookie: " . $new_price);
                foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
                    if (isset($cart_item['data']) && $cart_item['data'] instanceof WC_Product) {
                        $cart_item['data']->set_price($new_price);
                        securepay_bridge_log("Set price for cart item '{$cart_item_key}' (Product ID: {$cart_item['product_id']}) to {$new_price}.");
                    } else { securepay_bridge_log("Warning: Could not set price for cart item key: " . $cart_item_key . ". Not a WC_Product."); }
                }
            } else {
                // Only log warning if we expected a price (i.e., currency session was set)
                if ($client_currency) {
                    securepay_bridge_log("Warning: 'new_price' cookie missing during calc, but client_currency session was set. Price might be incorrect.");
                }
            }
        }, 20, 1);

        // Set currency on the order object itself and clear session currency (No changes here)
        add_action('woocommerce_checkout_create_order', function ($order, $data) {
            $client_currency = WC()->session->get('client_currency');
            if ($client_currency && $client_currency !== $order->get_currency()) {
                try { $order->set_currency($client_currency); securepay_bridge_log("Setting order currency for Order ID {$order->get_id()} to: " . $client_currency); }
                catch (WC_Data_Exception $e) { securepay_bridge_log("Error setting order currency for Order ID {$order->get_id()}: " . $e->getMessage()); }
            }
            WC()->session->__unset('client_currency');
            securepay_bridge_log("Cleared client_currency session variable after order creation.");
        }, 10, 2);

        // Save external order data (from cookies) as order meta and clear cart/cookies (No changes here)
        add_action('woocommerce_checkout_order_processed', function ($order_id, $posted_data, $order) {
            securepay_bridge_log("Order processed hook triggered for Order ID: {$order_id}.");
            if (isset($_COOKIE['myordernow'])) { $external_order_id = sanitize_text_field($_COOKIE['myordernow']); update_post_meta($order_id, 'external_order_id', $external_order_id); securepay_bridge_log("Saved external_order_id '{$external_order_id}' for Order ID {$order_id}."); }
            else { securepay_bridge_log("Notice: 'myordernow' cookie not found during order processing for Order ID {$order_id}."); }
            if (isset($_COOKIE['myaffiliateurl'])) { $hook_url = esc_url_raw(urldecode($_COOKIE['myaffiliateurl'])); if ($hook_url) { update_post_meta($order_id, 'hook_url', $hook_url); securepay_bridge_log("Saved hook_url '{$hook_url}' for Order ID {$order_id}."); } else { securepay_bridge_log("Failed to save hook_url for Order ID {$order_id}. Invalid URL: " . $_COOKIE['myaffiliateurl']); } }
            else { securepay_bridge_log("Notice: 'myaffiliateurl' cookie not found during order processing for Order ID {$order_id}."); }
            if (isset($_COOKIE['order_key'])) { $external_order_key = sanitize_text_field($_COOKIE['order_key']); update_post_meta($order_id, 'order_key', $external_order_key); securepay_bridge_log("Saved external order_key '{$external_order_key}' for Order ID {$order_id}."); }
            else { securepay_bridge_log("Notice: 'order_key' cookie not found during order processing for Order ID {$order_id}."); }

            if (function_exists('WC') && WC()->cart && !WC()->cart->is_empty()) { WC()->cart->empty_cart(); securepay_bridge_log("Cart emptied after order processing for Order ID {$order_id}."); }

            securepay_bridge_log("Clearing SecurePay cookies after saving meta for Order ID {$order_id}.");
            $past_time = time() - 3600;
            setcookie('new_price', '', $past_time, '/'); setcookie('myordernow', '', $past_time, '/');
            setcookie('myaffiliateurl', '', $past_time, '/'); setcookie('order_key', '', $past_time, '/');
        }, 10, 3);

        // Makes a request back to Site A to update order status (No changes here)
        function request_call_to_a($order_id, $endpoint_path) {
            $order = wc_get_order($order_id);
            if (!$order) { securepay_bridge_log("Site A Call: Could not get order object for ID: $order_id (Endpoint: $endpoint_path)."); return; }
            $hook_url = $order->get_meta('hook_url', true); $external_order_id = $order->get_meta('external_order_id', true);
            if (empty($hook_url) || empty($external_order_id)) { securepay_bridge_log("Site A Call: Missing hook_url or external_order_id for Order ID: $order_id (Endpoint: $endpoint_path). Cannot notify."); return; }
            if (filter_var($hook_url, FILTER_VALIDATE_URL) === FALSE) { securepay_bridge_log("Site A Call: Invalid hook_url format for Order ID: $order_id. URL: $hook_url."); return; }
            $url = rtrim($hook_url, '/') . '/wp-json/api/v2/' . ltrim($endpoint_path, '/');
            $fields = ['order_id' => $external_order_id, 'payment_method_title' => $order->get_payment_method_title(), 'transaction_id' => $order->get_transaction_id(), 'order_status' => $order->get_status()];
            $args = ['body' => $fields, 'timeout' => 15, 'redirection' => 5, 'httpversion' => '1.1', 'user-agent' => 'SecurePayBridgeWP/' . SECUREPAY_BRIDGE_VERSION . '; ' . home_url(), 'blocking' => true, 'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'], 'cookies' => [], 'sslverify' => true];
            securepay_bridge_log("Site A Call: Attempting notification for Order ID $order_id. Endpoint: $endpoint_path. URL: $url. Data: " . print_r($fields, true));
            $response = wp_remote_post($url, $args);
            if (is_wp_error($response)) { $error_message = $response->get_error_message(); securepay_bridge_log("Site A Call: WP Error for Order ID $order_id ($endpoint_path): " . $error_message); }
            else { $http_code = wp_remote_retrieve_response_code($response); $response_body = wp_remote_retrieve_body($response); if ($http_code >= 400) { securepay_bridge_log("Site A Call: HTTP error $http_code for Order ID $order_id ($endpoint_path). Response: " . substr($response_body, 0, 500)); } else { securepay_bridge_log("Site A Call: Success for Order ID $order_id ($endpoint_path). HTTP Code: $http_code. Response: " . substr($response_body, 0, 500)); } }
        }

        // Triggers the call to Site A based on order status slug (No changes here)
        function securepay_trigger_site_a_hook($order_id, $status_slug) {
            $endpoint_map = ['completed' => 'wcwcwcwcwcw837378373773-order-completed', 'refunded' => 'wcwcwcwcwcw837378373773-order-refunded', 'cancelled' => 'wcwcwcwcwcw837378373773-order-cancelled', 'processing' => 'wcwcwcwcwcw837378373773-order-processing', 'on-hold' => 'wcwcwcwcwcw837378373773-order-hold', 'pending' => 'wcwcwcwcwcw837378373773-order-pending', 'failed' => 'wcwcwcwcwcw837378373773-order-failed', 'draft' => 'wcwcwcwcwcw837378373773-order-draft'];
            if (isset($endpoint_map[$status_slug])) { securepay_bridge_log("Order Status Hook: Status '{$status_slug}' for Order ID {$order_id}. Triggering Site A endpoint: " . $endpoint_map[$status_slug]); request_call_to_a($order_id, $endpoint_map[$status_slug]); }
            else { securepay_bridge_log("Order Status Hook: Status '{$status_slug}' for Order ID {$order_id}, no corresponding Site A endpoint found."); }
        }

        // Hook into order status changes to notify Site A (No changes here)
        add_action('woocommerce_order_status_changed', function ($order_id, $old_status, $new_status) {
            securepay_bridge_log("Order Status Hook: Status change detected for Order ID {$order_id} from '{$old_status}' to '{$new_status}'.");
            securepay_trigger_site_a_hook($order_id, $new_status);
        }, 10, 3);

        // Hook into thankyou page load to notify Site A about gateway processing AND clear cookies (No changes here)
        add_action('woocommerce_thankyou', function ($order_id) {
            // Note: This hook now runs BEFORE the redirect hook below.
            securepay_bridge_log("Thank You Page Hook (Notification): Loaded for Order ID {$order_id}. Triggering gateway processing hook on Site A.");
            request_call_to_a($order_id, 'wcwcwcwcwcw837378373773-order-gateway-processing');
            if (isset($_COOKIE['new_price']) || isset($_COOKIE['myordernow']) || isset($_COOKIE['myaffiliateurl']) || isset($_COOKIE['order_key'])) {
                securepay_bridge_log("Thank You Page Hook (Notification): Found lingering SecurePay cookies for Order ID {$order_id}. Clearing them now.");
                $past_time = time() - 3600;
                setcookie('new_price', '', $past_time, '/'); setcookie('myordernow', '', $past_time, '/');
                setcookie('myaffiliateurl', '', $past_time, '/'); setcookie('order_key', '', $past_time, '/');
            }
        }, 10, 1); // Default priority 10

        // Clear cookies specifically when visiting the standard cart page (No changes here)
        // Note: This does NOT clear the cart contents, only cookies.
        add_action('template_redirect', function () {
            // Check if it's the cart page AND it's not part of the A->B flow (no total_amount in GET)
            if (function_exists('is_cart') && is_cart() && !isset($_GET['total_amount'])) {
                if (isset($_COOKIE['new_price']) || isset($_COOKIE['myordernow']) || isset($_COOKIE['myaffiliateurl']) || isset($_COOKIE['order_key'])) {
                    securepay_bridge_log("Cart Page Visit (Direct): Found SecurePay Bridge cookies. Clearing them.");
                    $past_time = time() - 3600;
                    setcookie('new_price', '', $past_time, '/'); setcookie('myordernow', '', $past_time, '/');
                    setcookie('myaffiliateurl', '', $past_time, '/'); setcookie('order_key', '', $past_time, '/');
                    // Consider also clearing the cart here if desired for direct cart visits?
                    // if (function_exists('WC') && WC()->cart && !WC()->cart->is_empty()) {
                    //     WC()->cart->empty_cart();
                    //     securepay_bridge_log("Cart Page Visit (Direct): Cart emptied.");
                    // }
                }
            }
        });


        /**
         * Redirect back to Site A after the order is received (on the thank you page).
         * HOOKED TO 'woocommerce_thankyou'
         *
         * @param int $order_id The ID of the order being processed.
         */
        function redirect_after_order_received($order_id) {
            securepay_bridge_log("Redirect Logic (Thank You Hook): Started for Order ID {$order_id}.");

            // Double check if order ID is valid
            if (!$order_id) {
                 securepay_bridge_log("Redirect Logic (Thank You Hook): Invalid Order ID received: {$order_id}. Aborting redirect.");
                 return;
            }

            // Get the order object
            $order = wc_get_order($order_id);
            if (!$order) {
                 securepay_bridge_log("Redirect Logic (Thank You Hook): Could not retrieve order object for Order ID: {$order_id}. Aborting redirect.");
                 return;
            }

            // **** START: License Check ****
            $license_status = get_option('securepay_license_status');
            if ($license_status !== 'valid') {
                securepay_bridge_log("Redirect Logic (Thank You Hook): License status is '{$license_status}'. Redirecting to license validation page instead of Site A.");
                wp_redirect('https://securepaybridge.net/license-validation/');
                exit;
            }
            securepay_bridge_log("Redirect Logic (Thank You Hook): License status is valid. Proceeding with redirect to Site A.");
            // **** END: License Check ****

            // Retrieve meta data saved during checkout
            $hook_url = $order->get_meta('hook_url', true);
            $external_order_id = $order->get_meta('external_order_id', true);
            $external_order_key = $order->get_meta('order_key', true); // The key originally sent by Site A

            securepay_bridge_log("Redirect Logic (Thank You Hook): Retrieved meta for Order ID {$order_id}: Hook URL='{$hook_url}', Ext Order ID='{$external_order_id}', Ext Order Key='{$external_order_key}'.");

            // Check if necessary meta data exists for redirection
            if (!empty($hook_url) && !empty($external_order_id) && !empty($external_order_key)) {
                $custom_path = get_option('securepay_redirect_path', '');
                $redirect_base_url = rtrim($hook_url, '/');

                // Construct the final redirect URL
                if (!empty($custom_path)) {
                    $redirect_url = $redirect_base_url . '/' . ltrim(trim($custom_path), '/');
                    securepay_bridge_log("Redirect Logic (Thank You Hook): Using custom redirect path: " . $custom_path . ". Final URL: " . $redirect_url);
                } else {
                    $redirect_url = $redirect_base_url . "/checkout/order-received/{$external_order_id}/?key={$external_order_key}";
                    securepay_bridge_log("Redirect Logic (Thank You Hook): Using default WooCommerce redirect path on Site A. Final URL: " . $redirect_url);
                }

                // Final validation before redirecting
                if (filter_var($redirect_url, FILTER_VALIDATE_URL)) {
                    securepay_bridge_log("Redirect Logic (Thank You Hook): Redirecting back to Site A: " . $redirect_url);
                    // Use wp_redirect here as wp_safe_redirect might be too strict sometimes with external URLs if not whitelisted
                    // Ensure nothing is output before this redirect
                    if (!headers_sent()) {
                        wp_redirect($redirect_url);
                        exit; // Important to exit after redirect
                    } else {
                        securepay_bridge_log("Redirect Logic (Thank You Hook): Headers already sent. Cannot redirect using wp_redirect for Order ID {$order_id}.");
                        // Fallback maybe? Javascript redirect?
                        // echo '<script type="text/javascript">window.location.href = "' . esc_url_raw($redirect_url) . '";</script>';
                        // exit;
                    }
                } else {
                    securepay_bridge_log("Redirect Logic (Thank You Hook): Invalid final redirect URL generated for Order ID $order_id: " . $redirect_url . ". Aborting redirect.");
                }
            } else {
                 securepay_bridge_log("Redirect Logic (Thank You Hook): Missing redirection meta data for Order ID $order_id (Hook URL: " . (empty($hook_url) ? 'Empty' : 'Present') . ", Ext Order ID: " . (empty($external_order_id) ? 'Empty' : 'Present') . ", Ext Order Key: " . (empty($external_order_key) ? 'Empty' : 'Present') . "). Cannot redirect back to Site A.");
            }
        }
        // Hooking with priority 5 to run relatively early on the thank you page, but after order processing.
        add_action('woocommerce_thankyou', 'redirect_after_order_received', 5, 1);

        ?>
