<?php
/**
 * @package Woocomerce-Rest-A
 */
/*
Plugin Name: SecurePay Bridge – High Risk Site
Plugin URI: https://securepaybridge.net
Description: Seamlessly route WooCommerce order data from your high-risk store to a secure low-risk processor using REST API technology.
Version: 13.6.5
Author: SecurePay Bridge
Author URI: https://securepaybridge.net
*/

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin version constant (if not already defined)
if (!defined('SECUREPAY_BRIDGE_A_VERSION')) { // Use a different constant name for plugin A
    define('SECUREPAY_BRIDGE_A_VERSION', '13.6.5'); // Match the version in the header
}

// Include the plugin updater class for Plugin A
require_once plugin_dir_path(__FILE__) . 'includes/plugin-updater-a.php'; // Include the new file

// Instantiate the updater class for Plugin A
$securepay_bridge_a_updater = new SecurePay_Bridge_Updater_A( // Use the new class name
    __FILE__, // Main plugin file path
    'https://auth.securepaybridge.net/update-check.php', // Your actual update server API endpoint
    plugin_basename(__FILE__), // Plugin slug (e.g., 'woocommerce-rest-a/woocommerce-rest-a.php')
    SECUREPAY_BRIDGE_A_VERSION // Current version constant for plugin A
);


add_action('plugins_loaded', 'init_highriskshop_rest_api_gateway');

function init_highriskshop_rest_api_gateway() {
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    class WC_highriskshop_rest_api_Gateway extends WC_Payment_Gateway {
        public $lowrisk_shop_url;
        public $license_key; // Added property
        public $license_token; // Added property

        public function __construct() {
            $this->id = 'highriskshop_rest_api';
            $this->has_fields = false;
            $this->method_title = 'SecurePay Bridge – High Risk Site';
            $this->method_description = 'This payment method will basically redirect the customer anonymously to your front shop allowing you to receive the payment using another Woocommerce installation using REST API';

            // Load the form fields.
            $this->init_form_fields();

            // Load the settings.
            $this->init_settings();

            // Define user set variables.
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->lowrisk_shop_url = $this->get_option('lowrisk_shop_url');
            // Get license settings using get_option
            $this->license_key = $this->get_option('securepay_a_license_key');
            $this->license_token = $this->get_option('securepay_a_license_token');

            $this->icon = plugin_dir_url(__FILE__) . 'credit-cards.png';

            // Actions
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            // REMOVED: Hook for adding admin scripts as button is removed
            // add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
        }

        /**
         * Initialize Gateway Settings Form Fields.
         */
        public function init_form_fields() {
             // Get the stored license status to display it
             $stored_status = get_option('securepay_a_license_status', 'unknown');
             $status_text = ucfirst($stored_status);
             $status_color = 'gray'; // Default color
             if ($stored_status === 'valid') {
                 $status_color = 'green';
             } elseif ($stored_status !== 'unknown') {
                 $status_color = 'red'; // Invalid, expired, error etc.
             }
             $status_display = sprintf(
                '<strong style="color: %s;">%s</strong>',
                esc_attr($status_color),
                esc_html($status_text)
             );

            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'woocommerce-rest-a'),
                    'type' => 'checkbox',
                    'label' => __('Enable SecurePay Bridge Gateway', 'woocommerce-rest-a'),
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Title', 'woocommerce-rest-a'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', 'woocommerce-rest-a'),
                    'default' => __('Credit Card', 'woocommerce-rest-a'),
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => __('Description', 'woocommerce-rest-a'),
                    'type' => 'textarea',
                    'description' => __('This controls the description which the user sees during checkout.', 'woocommerce-rest-a'),
                    'default' => __('Pay by your credit or debit card', 'woocommerce-rest-a'),
                ),
                'lowrisk_shop_url' => array(
                    'title' => __('Low Risk Shop URL', 'woocommerce-rest-a'),
                    'type' => 'text',
                    'description' => __('Insert the full URL of your low-risk shop.', 'woocommerce-rest-a'),
                    'default' => '',
                    'desc_tip' => true,
                ),
                // --- License Settings Section ---
                'license_settings_title' => array(
                    'title' => __('License Settings', 'woocommerce-rest-a'),
                    'type' => 'title',
                    'description' => __('Enter your license details obtained from SecurePay Bridge.', 'woocommerce-rest-a'),
                ),
                'securepay_a_license_key' => array(
                    'title' => __('License Key', 'woocommerce-rest-a'),
                    'type' => 'text', // Changed to text for visibility, consider 'password' if needed
                    'description' => __('Enter your SecurePay Bridge license key for this site.', 'woocommerce-rest-a'),
                    'default' => '',
                    'desc_tip' => true,
                    'custom_attributes' => array('required' => 'required'), // Add required attribute
                ),
                'securepay_a_license_token' => array(
                    'title' => __('License Token', 'woocommerce-rest-a'),
                    'type' => 'text', // Changed to text for visibility, consider 'password' if needed
                    'description' => __('Enter your SecurePay Bridge license token.', 'woocommerce-rest-a'),
                    'default' => '',
                    'desc_tip' => true,
                    'custom_attributes' => array('required' => 'required'), // Add required attribute
                ),
                 // --- Display Stored License Status (Moved Here) ---
                 'securepay_a_license_status_display' => array(
                    'title' => __('Current License Status', 'woocommerce-rest-a'),
                    'type' => 'title', // Use title type for simple display
                    'description' => $status_display . '<br><small>' . __('Status is updated automatically when you save settings.', 'woocommerce-rest-a') . '</small>',
                ),
                // REMOVED: License Check Button field
                // 'license_check_button' => array( ... ),
            );
        }

        // REMOVED: generate_license_check_button_html() function as it's no longer needed

        // REMOVED: admin_scripts() function as it's no longer needed

        /**
         * Process Admin Options.
         * Saves settings and performs license check after saving.
         */
        public function process_admin_options() {
            // First, let the parent class save the options from the form.
            $saved = parent::process_admin_options();

            // Now, retrieve the newly saved license key and token.
            // We use $this->get_option() which reads the recently saved values.
            $new_license_key = $this->get_option('securepay_a_license_key');
            $new_license_token = $this->get_option('securepay_a_license_token');

            $check_result = $this->perform_license_check_api($new_license_key, $new_license_token);

            // Update the stored license status based on the check result
            update_option('securepay_a_license_status', $check_result['status']);

            // Add an admin notice to give feedback on the check result
            if ($check_result['status'] === 'valid') {
                WC_Admin_Settings::add_message(__('License check successful: Status is Valid.', 'woocommerce-rest-a'));
            } elseif ($check_result['status'] === 'error') {
                 WC_Admin_Settings::add_error(sprintf(__('License check failed: %s', 'woocommerce-rest-a'), $check_result['message']));
            } else {
                // Handle other statuses like invalid, expired etc.
                 WC_Admin_Settings::add_error(sprintf(__('License check result: Status is %s. Message: %s', 'woocommerce-rest-a'), ucfirst($check_result['status']), $check_result['message']));
            }

            // Return the result from the parent save operation
            return $saved;
        }


        /**
         * Performs the actual API call to check the license.
         * Separated for clarity and potential reuse.
         *
         * @param string $license_key The license key to check.
         * @param string $license_token The license token to check.
         * @return array Containing 'status' (string) and 'message' (string).
         */
        private function perform_license_check_api($license_key, $license_token) {
            $default_error = ['status' => 'error', 'message' => __('License check could not be performed.', 'woocommerce-rest-a')];

            if (empty($license_key) || empty($license_token)) {
                error_log('[SecurePay Bridge A] License check API call skipped: Key or Token missing.');
                return ['status' => 'unknown', 'message' => __('License key or token is empty.', 'woocommerce-rest-a')];
            }

            // Get the current site domain
            $site_url = site_url();
            $domain = preg_replace('#^https?://(www\.)?#i', '', $site_url);
            $domain = strtolower(rtrim($domain, '/'));

            $api_url = 'https://auth.securepaybridge.net/license-check.php';
            $request_data = ['domain' => $domain, 'key' => $license_key, 'token' => $license_token];

            $response = wp_remote_post($api_url, [
                'method' => 'POST', 'timeout' => 20, 'redirection' => 5, 'httpversion' => '1.1',
                'sslverify' => true, 'body' => $request_data,
                'headers' => [
                    'Accept' => 'application/json',
                    'User-Agent' => 'SecurePayBridgeWPA/' . SECUREPAY_BRIDGE_A_VERSION . '; ' . home_url(),
                    'Content-Type' => 'application/x-www-form-urlencoded',
                ], 'cookies' => []
            ]);

            if (is_wp_error($response)) {
                $error_message = $response->get_error_message();
                error_log('[SecurePay Bridge A] License check API WP Error: ' . $error_message);
                return ['status' => 'error', 'message' => __('Connection error:', 'woocommerce-rest-a') . ' ' . $error_message];
            }

            $http_code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if ($http_code !== 200 || $data === null || !isset($data['status'])) {
                error_log("[SecurePay Bridge A] License check API failed: Invalid response from server (HTTP: $http_code). Body: " . substr($body, 0, 200));
                return ['status' => 'error', 'message' => __('Invalid response from license server.', 'woocommerce-rest-a') . " (HTTP: $http_code)"];
            }

            // Return the status and message from the API response
            return [
                'status' => isset($data['status']) ? strtolower(trim($data['status'])) : 'unknown',
                'message' => isset($data['message']) ? sanitize_text_field($data['message']) : __('No message received.', 'woocommerce-rest-a')
            ];
        }


        /**
         * Check license validity before processing payment.
         * Uses the license key and token stored in the gateway settings.
         * This function remains largely the same but now relies on the status updated by process_admin_options.
         *
         * @return bool True if license is valid, false otherwise.
         */
        private function check_license_validity() {
            // Retrieve license key and token directly from the settings using $this->get_option()
            $license_key = $this->get_option('securepay_a_license_key');
            $license_token = $this->get_option('securepay_a_license_token');
            $stored_status = get_option('securepay_a_license_status', 'unknown'); // Get the stored status

            if (empty($license_key) || empty($license_token)) {
                error_log('[SecurePay Bridge A] Payment blocked: Key or Token missing in gateway settings.');
                return false; // Cannot proceed without key/token
            }

            // Primarily rely on the stored status which should be updated on settings save.
            if ($stored_status === 'valid') {
                return true;
            } else {
                 error_log("[SecurePay Bridge A] Payment blocked: Stored license status is '{$stored_status}'.");
                 // Optional: You could perform a live check here as a fallback,
                 // but it adds overhead to every transaction. Relying on the stored
                 // status updated on save is generally preferred.
                 // $live_check_result = $this->perform_license_check_api($license_key, $license_token);
                 // return $live_check_result['status'] === 'valid';
                 return false;
            }
        }

        /**
         * Process the payment and return the result.
         *
         * @param int $order_id Order ID.
         * @return array Redirect URL or failure notice.
         */
        public function process_payment($order_id) {

            // --- START License Check ---
            if (!$this->check_license_validity()) {
                // License is invalid or check failed
                $purchase_url = 'https://securepaybridge.net/'; // Purchase URL
                $error_message = sprintf(
                    // Updated error message with purchase link
                    __('Payment cannot be processed due to a license validation issue. Please check your license status or <a href="%s" target="_blank">purchase a valid license</a>.', 'woocommerce-rest-a'),
                    esc_url($purchase_url) // Use the purchase URL here
                );
                wc_add_notice($error_message, 'error');
                // Return failure to prevent redirect and show notice
                return ['result' => 'failure'];
                // Execution stops here if license is invalid
            }
            // --- END License Check ---

            // --- Original Payment Processing Logic (if license is valid) ---
            $order = wc_get_order($order_id);
            if (!$order) {
                 wc_add_notice(__('Invalid order.', 'woocommerce-rest-a'), 'error');
                 return ['result' => 'failure'];
            }

            $myordernow = $order->get_id();
            $myaffiliateurl = home_url();

            // Ensure low-risk URL is set
            if (empty($this->lowrisk_shop_url)) {
                 wc_add_notice(__('Payment gateway configuration error: Low Risk Shop URL is not set.', 'woocommerce-rest-a'), 'error');
                 error_log('[SecurePay Bridge A] Payment failed: Low Risk Shop URL is empty in settings.');
                 return ['result' => 'failure'];
            }

            $params = array(
                'total_amount' => urlencode($order->get_total()),
                'billing_first_name' => urlencode($order->get_billing_first_name()),
                'billing_last_name' => urlencode($order->get_billing_last_name()),
                'billing_email' => urlencode($order->get_billing_email()),
                'billing_company' => urlencode($order->get_billing_company()),
                'billing_address_1' => urlencode($order->get_billing_address_1()),
                'billing_address_2' => urlencode($order->get_billing_address_2()),
                'billing_city' => urlencode($order->get_billing_city()),
                'billing_state' => urlencode($order->get_billing_state()),
                'billing_postcode' => urlencode($order->get_billing_postcode()),
                'billing_country' => urlencode($order->get_billing_country()),
                'billing_phone' => urlencode($order->get_billing_phone()),
                'currency' => urlencode($order->get_currency()),
                'myordernow' => urlencode($myordernow),
                'myaffiliateurl' => urlencode($myaffiliateurl),
                'order_key' => urlencode($order->get_order_key()),
            );

            $strtozmdjdjnjdn = rtrim($this->lowrisk_shop_url, '/');
            // Ensure the path to paynow-checkout.php is correct relative to the low-risk site URL
            $djndndkjndkjndee = $strtozmdjdjnjdn . '/wp-content/plugins/woocommerce-rest-b/paynow-checkout.php';
            $tozawyredirect_url = add_query_arg($params, $djndndkjndkjndee);

            return array(
                'result' => 'success',
                'redirect' => $tozawyredirect_url,
            );
        }

    } // End WC_highriskshop_rest_api_Gateway class

    /**
     * Add the Gateway to WooCommerce.
     *
     * @param array $methods WooCommerce payment methods.
     * @return array Filtered payment methods.
     */
    function add_highriskshop_rest_api_gateway($methods) {
        $methods[] = 'WC_highriskshop_rest_api_Gateway';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'add_highriskshop_rest_api_gateway');

} // End init_highriskshop_rest_api_gateway function


/**
 * Handles incoming REST API calls from Site B to update order status.
 */
class WC_Rest_API {
    public function __construct() {
        add_action('rest_api_init', array(
            $this,
            'init_rest_api'
        ));
    }

    public function init_rest_api() {
        $namespace = 'api/v2'; // Define namespace

        // Helper function for permission check (example - adjust as needed)
        $permission_callback = function () {
            // In a real scenario, you'd check for an API key, secret, IP address, or nonce
            // sent from Site B to ensure only authorized requests can update orders.
            // For now, keeping it simple, but THIS IS A SECURITY RISK IN PRODUCTION.
            // Consider adding a secret key check passed in the POST request from Site B.
            // Example:
            // $secret_key_from_b = isset($_POST['securepay_secret']) ? sanitize_text_field($_POST['securepay_secret']) : '';
            // $expected_secret = 'YOUR_SHARED_SECRET_KEY'; // Store this securely
            // return hash_equals($expected_secret, $secret_key_from_b);
            return true; // WARNING: Allows any request - replace with proper validation
        };

        // --- REST API endpoints for order status updates ---
        $endpoints = [
            'completed' => 'wcwcwcwcwcwcw82828282844_change_order_to_completed',
            'refunded' => 'wcwcwcwcwcwcw82828282844_change_order_to_refunded',
            'cancelled' => 'wcwcwcwcwcwcw82828282844_change_order_to_cancelled',
            'processing' => 'wcwcwcwcwcwcw82828282844_change_order_to_processing',
            'gateway-processing' => 'wcwcwcwcwcwcw82828282844_handle_gateway_processing', // Special case
            'hold' => 'wcwcwcwcwcwcw82828282844_change_order_to_hold',
            'pending' => 'wcwcwcwcwcwcw82828282844_change_order_to_pending',
            'failed' => 'wcwcwcwcwcwcw82828282844_change_order_to_failed',
            'draft' => 'wcwcwcwcwcwcw82828282844_change_order_to_draft', // Note: 'draft' is not standard
        ];

        foreach ($endpoints as $status => $callback_method) {
            register_rest_route($namespace, '/wcwcwcwcwcw837378373773-order-' . $status, array(
                'methods' => 'POST',
                'callback' => array($this, $callback_method),
                'permission_callback' => $permission_callback,
                'args' => [ // Define expected arguments
                    'order_id' => [
                        'required' => true,
                        'validate_callback' => function($param, $request, $key) {
                            return is_numeric($param) && $param > 0;
                        },
                        'sanitize_callback' => 'absint',
                    ],
                    'transaction_id' => [ // Optional transaction ID
                        'required' => false,
                        'validate_callback' => function($param, $request, $key) {
                            return is_string($param);
                        },
                        'sanitize_callback' => 'sanitize_text_field',
                    ],
                    // Add other potential args like 'payment_method_title', 'order_status' if needed
                ],
            ));
        }
    }

    /**
     * Generic function to update order status.
     *
     * @param WP_REST_Request $request Full data about the request.
     * @param string $new_status The target WooCommerce order status (e.g., 'completed', 'processing').
     * @param string $note Optional note to add to the order.
     * @return WP_REST_Response
     */
    private function update_order_status(WP_REST_Request $request, $new_status, $note = '') {
        $order_id = $request->get_param('order_id');
        $order = wc_get_order($order_id);

        if (!$order) {
            return new WP_REST_Response(['success' => false, 'message' => "Order ID $order_id not found."], 404);
        }

        try {
            $default_note = __('Order status updated by SecurePay Bridge.', 'woocommerce-rest-a');
            $order->update_status($new_status, $note ?: $default_note);
            return new WP_REST_Response(['success' => true, 'message' => "Order $order_id status updated to $new_status."], 200);
        } catch (Exception $e) {
            error_log("[SecurePay Bridge A] Error updating order $order_id to $new_status: " . $e->getMessage());
            return new WP_REST_Response(['success' => false, 'message' => "Error updating order status: " . $e->getMessage()], 500);
        }
    }

    // --- Callback Functions ---

    public function wcwcwcwcwcwcw82828282844_change_order_to_completed(WP_REST_Request $request) {
        return $this->update_order_status($request, 'completed');
    }

    public function wcwcwcwcwcwcw82828282844_change_order_to_refunded(WP_REST_Request $request) {
        return $this->update_order_status($request, 'refunded');
    }

    public function wcwcwcwcwcwcw82828282844_change_order_to_cancelled(WP_REST_Request $request) {
        return $this->update_order_status($request, 'cancelled');
    }

    // Handles the 'gateway-processing' call from Site B (typically after thankyou page load)
    public function wcwcwcwcwcwcw82828282844_handle_gateway_processing(WP_REST_Request $request) {
        $order_id = $request->get_param('order_id');
        $transaction_id = $request->get_param('transaction_id'); // Get optional transaction ID
        $order = wc_get_order($order_id);

        if (!$order) {
            return new WP_REST_Response(['success' => false, 'message' => "Order ID $order_id not found."], 404);
        }

        // Check if order exists and is still in 'pending' status before marking payment complete
        if ($order->has_status('pending')) {
            try {
                 // Mark payment as complete (changes status to processing or completed depending on product type)
                 $order->payment_complete($transaction_id ?: ''); // Pass transaction ID if available
                 $order->add_order_note(__('Payment processed via SecurePay Bridge. Status updated.', 'woocommerce-rest-a'));
                 return new WP_REST_Response(['success' => true, 'message' => "Order $order_id payment marked complete."], 200);
            } catch (Exception $e) {
                 error_log("[SecurePay Bridge A] Error marking payment complete for order $order_id: " . $e->getMessage());
                 return new WP_REST_Response(['success' => false, 'message' => "Error marking payment complete: " . $e->getMessage()], 500);
            }
        } else {
            // If order is not pending, just add a note indicating the call was received
             $order->add_order_note(__('SecurePay Bridge notification received (gateway processing). Current status: ', 'woocommerce-rest-a') . $order->get_status());
             return new WP_REST_Response(['success' => true, 'message' => "Notification received for order $order_id (already processed)."], 200);
        }
    }

    // Handles the explicit 'processing' status update call from Site B
    public function wcwcwcwcwcwcw82828282844_change_order_to_processing(WP_REST_Request $request) {
         $order_id = $request->get_param('order_id');
         $transaction_id = $request->get_param('transaction_id');
         $order = wc_get_order($order_id);

         if (!$order) {
             return new WP_REST_Response(['success' => false, 'message' => "Order ID $order_id not found."], 404);
         }

         try {
             // Check if payment needs to be marked complete first (e.g., if coming from pending)
             if ($order->has_status('pending')) {
                 $order->payment_complete($transaction_id ?: '');
             }
             // Ensure status is updated to processing
             $order->update_status('processing', __('Order status updated to Processing by SecurePay Bridge.', 'woocommerce-rest-a'));
             return new WP_REST_Response(['success' => true, 'message' => "Order $order_id status updated to processing."], 200);
         } catch (Exception $e) {
             error_log("[SecurePay Bridge A] Error updating order $order_id to processing: " . $e->getMessage());
             return new WP_REST_Response(['success' => false, 'message' => "Error updating order status: " . $e->getMessage()], 500);
         }
    }

    public function wcwcwcwcwcwcw82828282844_change_order_to_hold(WP_REST_Request $request) {
        return $this->update_order_status($request, 'on-hold');
    }

    public function wcwcwcwcwcwcw82828282844_change_order_to_pending(WP_REST_Request $request) {
        // Usually, you wouldn't revert to pending after payment attempt, but handle as requested
        return $this->update_order_status($request, 'pending');
    }

     // Added handler for 'failed' status
     public function wcwcwcwcwcwcw82828282844_change_order_to_failed(WP_REST_Request $request) {
        return $this->update_order_status($request, 'failed', __('Order status updated to Failed by SecurePay Bridge.', 'woocommerce-rest-a'));
    }

     // Added handler for 'draft' status (Note: 'draft' is not a standard WC order status)
     // This might need custom handling depending on what 'draft' means in your workflow.
     // For now, it just adds a note.
     public function wcwcwcwcwcwcw82828282844_change_order_to_draft(WP_REST_Request $request) {
        $order_id = $request->get_param('order_id');
        $order = wc_get_order($order_id);

        if (!$order) {
            return new WP_REST_Response(['success' => false, 'message' => "Order ID $order_id not found."], 404);
        }

        // $order->update_status('draft'); // This will likely fail as 'draft' isn't standard
        $order->add_order_note(__('SecurePay Bridge notification received (draft status).', 'woocommerce-rest-a'));
        // Consider setting a custom status if you have one registered, or just adding the note.
        return new WP_REST_Response(['success' => true, 'message' => "Draft notification received for order $order_id."], 200);
    }
} // End WC_Rest_API class

// Instantiate the REST API handler
new WC_Rest_API();

// REMOVED: AJAX handler function securepay_a_ajax_check_license() as it's no longer needed

?>
