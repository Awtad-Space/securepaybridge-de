<?php
/**
 * SecurePay Bridge Plugin Updater Class for High Risk Site.
 * Handles checking for updates from a custom server WITHOUT license checks.
 * MODIFIED: Update check now bypasses license validation and relies only on version.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class SecurePay_Bridge_Updater_A { // Changed class name

    private $plugin_file;
    private $api_url; // URL of the update server API endpoint
    private $plugin_slug; // Plugin slug (folder-name/main-file.php)
    private $version; // Current plugin version

    /**
     * Constructor.
     *
     * @param string $plugin_file The main plugin file path (__FILE__).
     * @param string $api_url     The URL of the update server API endpoint (e.g., https://auth.securepaybridge.net/update-check.php).
     * @param string $plugin_slug The plugin slug (e.g., 'woocommerce-rest-a/woocommerce-rest-a.php').
     * @param string $version     The current plugin version.
     */
    public function __construct($plugin_file, $api_url, $plugin_slug, $version) {
        $this->plugin_file = $plugin_file;
        $this->api_url = $api_url;
        $this->plugin_slug = $plugin_slug;
        $this->version = $version;

        // Hook into the update check process
        add_filter('site_transient_update_plugins', array($this, 'inject_update'));

        // Hook into the plugins_api to provide plugin details
        add_filter('plugins_api', array($this, 'plugins_api_filter'), 10, 3);

        // Optional: Add a simple log for initialization
        // error_log("SecurePay Bridge Updater A: Initialized for slug '{$this->plugin_slug}' version '{$this->version}'. API URL: '{$this->api_url}'.");
    }

    /**
     * Inject update information into the update transient.
     * This makes the update appear in the WordPress admin.
     *
     * @param object $transient The update transient object.
     * @return object Modified transient object.
     */
    public function inject_update($transient) {
        // error_log("SecurePay Bridge Updater A: Running inject_update hook.");

        if (empty($transient) || !isset($transient->checked) || empty($transient->checked)) {
            // error_log("SecurePay Bridge Updater A: Transient is empty or missing checked plugins. Skipping injection.");
            return $transient;
        }

        // Query our update server for update information
        // We pass 'check_update' action to the server
        // IMPORTANT: We do NOT send license key, token, or domain here.
        $update_info = $this->query_update_server('check_update');

        // error_log("SecurePay Bridge Updater A: Received update_info from server: " . print_r($update_info, true));

        // Check if we received valid update information and if a new version is available
        // The check for license_status is REMOVED. Update is available if new_version exists and is greater than current.
        if ($update_info && is_object($update_info) && !empty($update_info->new_version) && version_compare($this->version, $update_info->new_version, '<')) {
            // An update is available. Add our plugin's update info to the transient response.
            // The 'package' property MUST be the URL to the zip file.
            $transient->response[$this->plugin_slug] = $update_info;
            // error_log("SecurePay Bridge Updater A: Injected update info for {$this->plugin_slug}. New version: {$update_info->new_version}. Package URL: " . ($update_info->package ?? 'N/A'));
        } else {
             // No update available or server response invalid
             unset($transient->response[$this->plugin_slug]);
             // error_log("SecurePay Bridge Updater A: No update available or server response invalid for {$this->plugin_slug}. Current version: {$this->version}.");
        }

        // error_log("SecurePay Bridge Updater A: Final transient state (after injection attempt): " . print_r($transient, true));

        return $transient;
    }

    /**
     * Filter the plugins_api response to provide plugin details when the user clicks "View details".
     *
     * @param false|object|array $result The result object or array. Default false.
     * @param string             $action The type of information being requested ('plugin_information').
     * @param object             $args   Arguments for the plugins_api request (contains 'slug').
     * @return object The plugin information object from our server, or the original result.
     */
    public function plugins_api_filter($result, $action, $args) {
        // error_log("SecurePay Bridge Updater A: Running plugins_api_filter hook for action '$action'. Requested slug: " . ($args->slug ?? 'N/A'));

        // Check if this request is for our plugin and the action is 'plugin_information'
        if ($action !== 'plugin_information' || empty($args->slug) || $args->slug !== $this->plugin_slug) {
            // error_log("SecurePay Bridge Updater A: Not our plugin or action. Returning original result.");
            return $result; // Not our plugin or action, return original result
        }

        // error_log("SecurePay Bridge Updater A: plugins_api_filter triggered for our plugin '{$this->plugin_slug}'. Querying update server for details.");

        // Query our update server for detailed plugin information
        // We pass 'plugin_information' action to the server
        // IMPORTANT: We do NOT send license key, token, or domain here.
        $plugin_info = $this->query_update_server('plugin_information');

        // The check for license_status is REMOVED. Return info if valid object is received.
        if ($plugin_info && is_object($plugin_info)) {
            // We received valid plugin information from our server
            // error_log("SecurePay Bridge Updater A: Successfully retrieved plugin information from server for details view.");
            return $plugin_info; // Return the information from our server
        }

        // If our server failed, return the original result (which might be false or default WP info)
        // error_log("SecurePay Bridge Updater A: Failed to retrieve plugin information from server for details view. Returning original result.");
        return $result;
    }

    /**
     * Query the custom update server API endpoint.
     *
     * @param string $action The action being performed ('check_update' or 'plugin_information').
     * @return object|false The response object from the server, or false on failure.
     */
    private function query_update_server($action) {
        // Ensure we have the necessary information to query the server
        if (empty($this->api_url)) {
            // error_log("SecurePay Bridge Updater A: Skipping update server query for action '$action' - API URL is missing.");
            return false; // Cannot query without API URL
        }

        // Prepare the data to send to the update server
        // IMPORTANT: Do NOT include license_key, token, or domain for this plugin.
        $request_args = array(
            'action'      => $action, // 'check_update' or 'plugin_information'
            'slug'        => $this->plugin_slug,
            'version'     => $this->version,
            // 'domain'      => $domain, // Removed
            // 'license_key' => $this->license_key, // Removed
            // 'license_token' => $this->license_token, // Removed
        );

        // error_log("SecurePay Bridge Updater A: Querying update server ('{$this->api_url}') for action '$action'. Sending data: " . print_r($request_args, true));

        // Use wp_remote_post to send data securely to the update server
        $response = wp_remote_post($this->api_url, array(
            'method'      => 'POST',
            'timeout'     => 20,
            'redirection' => 5,
            'httpversion' => '1.1',
            'user-agent'  => 'SecurePayBridgeWPAUpdater/' . $this->version . '; ' . home_url(), // Custom User-Agent for plugin A
            'blocking'    => true,
            'headers'     => array('Content-Type' => 'application/x-www-form-urlencoded'),
            'body'        => $request_args,
            'sslverify'   => true,
        ));

        // Check for WordPress HTTP errors
        if (is_wp_error($response)) {
            error_log("SecurePay Bridge Updater A: WP Error querying update server for action '$action': " . $response->get_error_message());
            return false;
        }

        $http_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        // error_log("SecurePay Bridge Updater A: Raw response from update server (HTTP $http_code): " . substr($body, 0, 500));

        // Check HTTP status code
        if ($http_code !== 200) {
             error_log("SecurePay Bridge Updater A: Update server returned non-200 HTTP code ($http_code) for action '$action'.");
             return false;
        }

        // Decode the JSON response
        $data = json_decode($body);

        // Check if JSON decoding was successful.
        // The check for license_status is REMOVED.
        if ($data === null || !is_object($data)) {
            error_log("SecurePay Bridge Updater A: Failed to decode JSON response for action '$action'. Body: " . substr($body, 0, 500));
            return false; // Treat as failure if response is not valid JSON
        }

        // If we reach here, the response is valid JSON.
        // We no longer check for license_status === 'valid' here.
        // The server is expected to return the update info if available.
        // The decision to show/install the update is now based purely on version_compare in inject_update.
        // error_log("SecurePay Bridge Updater A: Successfully queried update server for action '$action'. Received valid data.");
        return $data; // Return the decoded object
    }
}
?>
