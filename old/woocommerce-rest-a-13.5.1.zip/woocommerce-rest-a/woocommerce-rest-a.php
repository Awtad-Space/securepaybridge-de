<?php
/**
 * @package Woocomerce-Rest-A
 */
/*
Plugin Name: SecurePay Bridge – High Risk Site
Plugin URI: https://securepaybridge.net
Description: Seamlessly route WooCommerce order data from your high-risk store to a secure low-risk processor using REST API technology.
Version: 13.5.1
Author: SecurePay Bridge
Author URI: https://securepaybridge.net
*/

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin version constant (if not already defined)
if (!defined('SECUREPAY_BRIDGE_A_VERSION')) { // Use a different constant name for plugin A
    define('SECUREPAY_BRIDGE_A_VERSION', '13.5.1'); // Match the version in the header
}

// Include the plugin updater class for Plugin A
require_once plugin_dir_path(__FILE__) . 'includes/plugin-updater-a.php'; // Include the new file

// Instantiate the updater class for Plugin A
// Pass the main plugin file path, the update server API URL, the plugin slug, and the current version.
$securepay_bridge_a_updater = new SecurePay_Bridge_Updater_A( // Use the new class name
    __FILE__, // Main plugin file path
    'https://auth.securepaybridge.net/update-check.php', // Your actual update server API endpoint
    plugin_basename(__FILE__), // Plugin slug (e.g., 'woocommerce-rest-a/woocommerce-rest-a.php')
    SECUREPAY_BRIDGE_A_VERSION // Current version constant for plugin A
);


add_action('plugins_loaded', 'init_highriskshop_rest_api_gateway');

function init_highriskshop_rest_api_gateway() {
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    class WC_highriskshop_rest_api_Gateway extends WC_Payment_Gateway {
        public $lowrisk_shop_url;

        public function __construct() {
            $this->id = 'highriskshop_rest_api';
            $this->has_fields = false;
            $this->method_title = 'SecurePay Bridge – High Risk Site';
            $this->method_description = 'This payment method will basically redirect the customer anonymously to your front shop allowing you to receive the payment using another Woocommerce installation using REST API';
            $this->init_form_fields();
            $this->init_settings();

            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->lowrisk_shop_url = $this->get_option('lowrisk_shop_url');

            $this->icon = plugin_dir_url(__FILE__) . 'credit-cards.png';

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_api_highriskshop_rest_api_callback', array($this, 'check_callback_response'));
        }

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Enable/Disable',
                    'type' => 'checkbox',
                    'label' => 'Enable highriskshop_rest_api Gateway',
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => 'Title',
                    'type' => 'text',
                    'description' => 'This controls the title which the user sees during checkout.',
                    'default' => 'Credit Card',
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => 'Description',
                    'type' => 'textarea',
                    'description' => 'This controls the description which the user sees during checkout.',
                    'default' => 'Pay by your credit or debit card',
                ),
                'lowrisk_shop_url' => array(
                    'title' => 'Low Risk Shop URL',
                    'type' => 'text',
                    'description' => 'Insert low risk shop URL',
                    'default' => '',
                    'desc_tip' => true,
                ),
            );
        }

        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
            $myordernow = $order->get_id();
            $myaffiliateurl = home_url();

            $params = array(
                'total_amount' => urlencode($order->get_total()),
                'billing_first_name' => urlencode($order->get_billing_first_name()),
                'billing_last_name' => urlencode($order->get_billing_last_name()),
                'billing_email' => urlencode($order->get_billing_email()),
                'billing_company' => urlencode($order->get_billing_company()),
                'billing_address_1' => urlencode($order->get_billing_address_1()),
                'billing_address_2' => urlencode($order->get_billing_address_2()),
                'billing_city' => urlencode($order->get_billing_city()),
                'billing_state' => urlencode($order->get_billing_state()),
                'billing_postcode' => urlencode($order->get_billing_postcode()),
                'billing_country' => urlencode($order->get_billing_country()),
                'billing_phone' => urlencode($order->get_billing_phone()),
                'currency' => urlencode($order->get_currency()),
                'myordernow' => urlencode($myordernow),
                'myaffiliateurl' => urlencode($myaffiliateurl),
                'order_key' => urlencode($order->get_order_key()),
            );

            $strtozmdjdjnjdn = rtrim($this->lowrisk_shop_url, '/');
            $djndndkjndkjndee = $strtozmdjdjnjdn . '/wp-content/plugins/woocommerce-rest-b/paynow-checkout.php';
            $tozawyredirect_url = add_query_arg($params, $djndndkjndkjndee);

            header("Referrer-Policy: no-referrer");
            return array(
                'result' => 'success',
                'redirect' => $tozawyredirect_url,
            );
        }
    }

    function add_highriskshop_rest_api_gateway($methods) {
        $methods[] = 'WC_highriskshop_rest_api_Gateway';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'add_highriskshop_rest_api_gateway');
}

class WC_Rest_API {
    public function __construct() {
        add_action('rest_api_init', array(
            $this,
            'init_rest_api'
        ));
    }

    public function init_rest_api() {
        register_rest_route('api/v2', '/wcwcwcwcwcw837378373773-order-completed', array(
            'methods' => 'POST',
            'callback' => array(
                $this,
                'wcwcwcwcwcwcw82828282844_change_order_to_completed'
            ),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('api/v2', '/wcwcwcwcwcw837378373773-order-refunded', array(
            'methods' => 'POST',
            'callback' => array(
                $this,
                'wcwcwcwcwcwcw82828282844_change_order_to_refunded'
            ),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('api/v2', '/wcwcwcwcwcw837378373773-order-cancelled', array(
            'methods' => 'POST',
            'callback' => array(
                $this,
                'wcwcwcwcwcwcw82828282844_change_order_to_cancelled'
            ),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('api/v2', '/wcwcwcwcwcw837378373773-order-processing', array(
            'methods' => 'POST',
            'callback' => array(
                $this,
                'wcwcwcwcwcwcw82828282844_change_order_to_processing'
            ),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('api/v2', '/wcwcwcwcwcw837378373773-order-zeftprocessing', array(
            'methods' => 'POST',
            'callback' => array(
                $this,
                'wcwcwcwcwcwcw82828282844_change_order_to_zeftprocessing'
            ),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('api/v2', '/wcwcwcwcwcw837378373773-order-hold', array(
            'methods' => 'POST',
            'callback' => array(
                $this,
                'wcwcwcwcwcwcw82828282844_change_order_to_hold'
            ),
            'permission_callback' => '__return_true',
        ));

        register_rest_route('api/v2', '/wcwcwcwcwcw837378373773-order-pending', array(
            'methods' => 'POST',
            'callback' => array(
                $this,
                'wcwcwcwcwcwcw82828282844_change_order_to_pending'
            ),
            'permission_callback' => '__return_true',
        ));
    }

    public function wcwcwcwcwcwcw82828282844_change_order_to_completed($data) {
        $order_id = $data['order_id'];
        $order = new WC_Order($order_id);
        if (!empty($order)) {
            $order->update_status('completed');
        }
    }

    public function wcwcwcwcwcwcw82828282844_change_order_to_refunded($data) {
        $order_id = $data['order_id'];
        $order = new WC_Order($order_id);
        if (!empty($order)) {
            $order->update_status('refunded');
        }
    }

    public function wcwcwcwcwcwcw82828282844_change_order_to_cancelled($data) {
        $order_id = $data['order_id'];
        $order = new WC_Order($order_id);
        if (!empty($order)) {
            $order->update_status('cancelled');
        }
    }

    public function wcwcwcwcwcwcw82828282844_change_order_to_zeftprocessing($data) {
        $order_id = $data['order_id'];
        $order = new WC_Order($order_id);
        if (!empty($order)) {
            if ($order->has_status('pending')) {
                $order->payment_complete();
                $order->update_status('processing');
            }
        }
    }

    public function wcwcwcwcwcwcw82828282844_change_order_to_processing($data) {
        $order_id = $data['order_id'];
        $order = new WC_Order($order_id);
        if (!empty($order)) {
            if ($order->has_status('pending')) {
                $order->payment_complete();
            }
            $order->update_status('processing');
        }
    }

    public function wcwcwcwcwcwcw82828282844_change_order_to_hold($data) {
        $order_id = $data['order_id'];
        $order = new WC_Order($order_id);
        if (!empty($order)) {
            $order->update_status('on-hold');
        }
    }

    public function wcwcwcwcwcwcw82828282844_change_order_to_pending($data) {
        $order_id = $data['order_id'];
        $order = new WC_Order($order_id);
        if (!empty($order)) {
            $order->update_status('pending');
        }
    }
}

new WC_Rest_API();
