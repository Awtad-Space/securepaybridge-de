jQuery(document).ready(function($) {
            const wrapper = $('.securepay-settings'); // Main settings container

            // --- Select2 Initialization ---
            function initializeSelect2(element) {
                if (typeof $.fn.select2 === 'function') {
                    try {
                        $(element).select2({
                            placeholder: $(element).data('placeholder') || securepay_settings_params.text_select_product || 'Select...',
                            width: '100%',
                            allowClear: true // Good for multi-selects too
                        });
                        // console.log('Select2 initialized for:', element); // Removed debug log
                    } catch (e) {
                        console.error('Error initializing Select2 for:', element, e);
                    }
                } else {
                    console.error('Select2 function ($.fn.select2) is not defined when trying to initialize:', element);
                }
            }

            // Initialize existing static Select2 elements on page load (including multi-selects)
            $('.securepay-select2').each(function() {
                initializeSelect2(this);
            });

            // --- Conditional Settings Visibility ---
            const modeRadios = wrapper.find('input[name="securepay_product_selection_mode"]');
            const conditionalSettings = wrapper.find('.securepay-setting-conditional'); // All conditional rows/wrappers

            function toggleConditionalSettings() {
                const selectedMode = wrapper.find('input[name="securepay_product_selection_mode"]:checked').val();
                // console.log('Selection mode changed to:', selectedMode); // Removed debug log

                conditionalSettings.hide(); // Hide all conditional sections first

                if (selectedMode) {
                    // Show the specific section for the selected mode
                    const sectionToShow = wrapper.find('.securepay-setting-' + selectedMode);
                    sectionToShow.show();
                    // console.log('Showing section:', '.securepay-setting-' + selectedMode); // Removed debug log
                }
            }

            // Initial toggle on page load
            toggleConditionalSettings();

            // Toggle on radio button change
            modeRadios.on('change', toggleConditionalSettings);


            // --- Price Conditions Management (Updated for Ranges & Multi-Product) ---
            const conditionsTbody = $('#securepay-price-conditions-tbody');
            // Clone the template row, remove its ID and display style
            const conditionTemplate = $('#securepay-condition-template').clone().removeAttr('id').css('display', '');

            // Function to re-index condition rows (important for PHP array keys)
            function reindexConditions() {
                conditionsTbody.find('tr:not(#securepay-condition-template)').each(function(index) {
                    $(this).find('select, input').each(function() {
                        const name = $(this).attr('name');
                        if (name) {
                            // Regex updated to handle potential '[]' for multi-select
                            const newName = name.replace(/\[\d+\]/, '[' + index + ']');
                            $(this).attr('name', newName);
                        }
                    });
                });
                 // console.log('Re-indexed price conditions.'); // Removed debug log
            }

            // Add Condition Button (Updated)
            $('#securepay-add-condition').on('click', function() {
                // console.log('Adding new price condition row.'); // Removed debug log
                // Use the cloned template
                const newRow = conditionTemplate.clone();

                // Populate product multi-select dropdown in the new row
                const productSelect = newRow.find('.securepay-condition-product');
                if (securepay_settings_params && securepay_settings_params.products) {
                    securepay_settings_params.products.forEach(function(product) {
                        productSelect.append($('<option>', {
                            value: product.id,
                            text: product.text // Already escaped in PHP
                        }));
                    });
                }

                conditionsTbody.append(newRow);
                initializeSelect2(newRow.find('.securepay-select2-dynamic')); // Initialize Select2 for the new multi-select dropdown
                reindexConditions(); // Re-index after adding
            });

            // Remove Condition Button (using event delegation)
            conditionsTbody.on('click', '.securepay-remove-condition', function() {
                // console.log('Removing price condition row.'); // Removed debug log
                // Destroy Select2 instance before removing the row to prevent memory leaks
                const selectElement = $(this).closest('tr').find('.securepay-select2');
                if (selectElement.data('select2')) {
                    selectElement.select2('destroy');
                }
                $(this).closest('tr').remove();
                reindexConditions(); // Re-index after removing
            });

            // Initial re-index on page load for existing conditions
            reindexConditions();

        });
