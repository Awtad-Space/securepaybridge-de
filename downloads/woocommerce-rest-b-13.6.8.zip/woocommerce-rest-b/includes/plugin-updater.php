<?php
        /**
         * SecurePay Bridge Plugin Updater Class.
         * Handles checking for updates from a custom server.
         * MODIFIED: Update check now bypasses license validation and relies only on version.
         */

        if ( ! defined( 'ABSPATH' ) ) {
            exit; // Exit if accessed directly
        }

        class SecurePay_Bridge_Updater {

            private $plugin_file;
            private $api_url; // URL of the update server API endpoint
            private $plugin_slug; // Plugin slug (folder-name/main-file.php)
            private $version; // Current plugin version
            // License key and token are no longer used for update checks in this modified version
            // private $license_key;
            // private $license_token;

            /**
             * Constructor.
             *
             * @param string $plugin_file The main plugin file path (__FILE__).
             * @param string $api_url     The URL of the update server API endpoint (e.g., https://securepaybridge.de/update-check.php).
             * @param string $plugin_slug The plugin slug (e.g., 'woocommerce-rest-b/woocommerce-rest-b.php').
             * @param string $version     The current plugin version.
             */
            public function __construct($plugin_file, $api_url, $plugin_slug, $version) {
                $this->plugin_file = $plugin_file;
                $this->api_url = $api_url; // This is now https://securepaybridge.de/update-check.php
                $this->plugin_slug = $plugin_slug;
                $this->version = $version;

                // License details are no longer retrieved or used for update checks
                // $this->license_key = get_option('securepay_license_key', '');
                // $this->license_token = get_option('securepay_license_token', '');

                // Hook into the update check process
                // Using site_transient_update_plugins to inject update info
                add_filter('site_transient_update_plugins', array($this, 'inject_update'));

                // Hook into the plugins_api to provide plugin details
                add_filter('plugins_api', array($this, 'plugins_api_filter'), 10, 3);

                // securepay_bridge_log("Plugin Updater: Initialized for slug '{$this->plugin_slug}' version '{$this->version}'. API URL: '{$this->api_url}'.");
                // securepay_bridge_log("Plugin Updater: Retrieved License Key (partial): " . substr($this->license_key, 0, 4) . "... Token (partial): " . substr($this->license_token, 0, 4) . "...");
            }

            /**
             * Inject update information into the update transient.
             * This makes the update appear in the WordPress admin.
             *
             * @param object $transient The update transient object.
             * @return object Modified transient object.
             */
            public function inject_update($transient) {
                // securepay_bridge_log("Plugin Updater: Running inject_update hook.");
                // securepay_bridge_log("Plugin Updater: Current transient state (before check): " . print_r($transient, true));


                // Check if the transient is valid and contains checked plugins
                if (empty($transient) || !isset($transient->checked) || empty($transient->checked)) {
                    // securepay_bridge_log("Plugin Updater: Transient is empty or missing checked plugins. Skipping injection.");
                    return $transient;
                }

                // Query our update server for update information
                // We pass 'check_update' action to the server
                // License details are NOT sent in this modified version
                $update_info = $this->query_update_server('check_update');

                // securepay_bridge_log("Plugin Updater: Received update_info from server: " . print_r($update_info, true));


                // Check if we received valid update information and if a new version is available
                // The check for license_status is REMOVED. Update is available if new_version exists and is greater than current.
                if ($update_info && is_object($update_info) && !empty($update_info->new_version) && version_compare($this->version, $update_info->new_version, '<')) {
                    // An update is available. Add our plugin's update info to the transient response.
                    // The update_info object should contain properties like:
                    // slug, new_version, url, package (download URL), maybe tested, requires, requires_php, etc.
                    // The 'package' property MUST be the URL to the zip file (e.g., update.securepaybridge.de/...).
                    $transient->response[$this->plugin_slug] = $update_info;
                    // securepay_bridge_log("Plugin Updater: Injected update info for {$this->plugin_slug}. New version: {$update_info->new_version}. Package URL: " . ($update_info->package ?? 'N/A'));
                } else {
                     // No update available, ensure no update info is present for our plugin
                     unset($transient->response[$this->plugin_slug]);
                     // securepay_bridge_log("Plugin Updater: No update available for {$this->plugin_slug}. Current version: {$this->version}.");
                }

                // securepay_bridge_log("Plugin Updater: Final transient state (after injection attempt): " . print_r($transient, true));

                return $transient;
            }

            /**
             * Filter the plugins_api response to provide plugin details when the user clicks "View details".
             *
             * @param false|object|array $result The result object or array. Default false.
             * @param string             $action The type of information being requested ('plugin_information').
             * @param object             $args   Arguments for the plugins_api request (contains 'slug').
             * @return object The plugin information object from our server, or the original result.
             */
            public function plugins_api_filter($result, $action, $args) {
                // securepay_bridge_log("Plugin Updater: Running plugins_api_filter hook for action '$action'. Requested slug: " . ($args->slug ?? 'N/A'));

                // Check if this request is for our plugin and the action is 'plugin_information'
                if ($action !== 'plugin_information' || empty($args->slug) || $args->slug !== $this->plugin_slug) {
                    // securepay_bridge_log("Plugin Updater: Not our plugin or action. Returning original result.");
                    return $result; // Not our plugin or action, return original result
                }

                // securepay_bridge_log("Plugin Updater: plugins_api_filter triggered for our plugin '{$this->plugin_slug}'. Querying update server for details.");

                // Query our update server for detailed plugin information
                // We pass 'plugin_information' action to the server
                // License details are NOT sent in this modified version
                $plugin_info = $this->query_update_server('plugin_information');

                // The check for license_status is REMOVED. Return info if valid object is received.
                if ($plugin_info && is_object($plugin_info)) {
                    // We received valid plugin information from our server
                    // securepay_bridge_log("Plugin Updater: Successfully retrieved plugin information from server for details view.");
                    return $plugin_info; // Return the information from our server
                }

                // If our server failed, return the original result (which might be false or default WP info)
                // securepay_bridge_log("Plugin Updater: Failed to retrieve plugin information from server for details view. Returning original result.");
                return $result;
            }

            /**
             * Query the custom update server API endpoint.
             *
             * @param string $action The action being performed ('check_update' or 'plugin_information').
             * @return object|false The response object from the server, or false on failure.
             */
            private function query_update_server($action) {
                // Ensure we have the necessary information to query the server
                if (empty($this->api_url)) {
                    // securepay_bridge_log("Plugin Updater: Skipping update server query for action '$action' - API URL is missing.");
                    return false; // Cannot query without necessary info
                }

                // Get the site domain for server-side logging/tracking (optional, not for license validation here)
                $site_url = site_url();
                $domain = preg_replace( '#^https?://(www\.)?#i', '', $site_url );
                $domain = strtolower(rtrim($domain, '/'));

                // Prepare the data to send to the update server
                // License key and token are REMOVED from the request args
                $request_args = array(
                    'action'      => $action, // 'check_update' or 'plugin_information'
                    'slug'        => $this->plugin_slug,
                    'version'     => $this->version,
                    'domain'      => $domain, // Still send domain for server-side tracking/logging if needed
                    // 'license_key' => $this->license_key, // Removed
                    // 'license_token' => $this->license_token, // Removed
                );

                // securepay_bridge_log("Plugin Updater: Querying update server ('{$this->api_url}') for action '$action'. Sending data: " . print_r($request_args, true));

                // Use wp_remote_post to send data securely to the update server
                $response = wp_remote_post($this->api_url, array(
                    'method'      => 'POST',
                    'timeout'     => 20, // Increased timeout slightly
                    'redirection' => 5,
                    'httpversion' => '1.1',
                    'user-agent'  => 'SecurePayBridgeWPUpdater/' . $this->version . '; ' . home_url(), // Custom User-Agent
                    'blocking'    => true, // Wait for the response
                    'headers'     => array('Content-Type' => 'application/x-www-form-urlencoded'), // Standard POST data
                    'body'        => $request_args, // The data to send
                    'sslverify'   => true, // Always verify SSL certificate
                ));

                // Check for WordPress HTTP errors
                if (is_wp_error($response)) {
                    // securepay_bridge_log("Plugin Updater: WP Error querying update server for action '$action': " . $response->get_error_message());
                    return false;
                }

                $http_code = wp_remote_retrieve_response_code($response);
                $body = wp_remote_retrieve_body($response);

                // securepay_bridge_log("Plugin Updater: Raw response from update server (HTTP $http_code): " . substr($body, 0, 500)); // Log first 500 chars

                // Check HTTP status code
                if ($http_code !== 200) {
                     // securepay_bridge_log("Plugin Updater: Update server returned non-200 HTTP code ($http_code) for action '$action'.");
                     return false;
                }

                // Decode the JSON response
                $data = json_decode($body);

                // Check if JSON decoding was successful
                // The check for license_status in the response is REMOVED.
                if ($data === null || !is_object($data)) {
                    // securepay_bridge_log("Plugin Updater: Failed to decode JSON response from update server for action '$action'. Body: " . substr($body, 0, 500));
                    return false;
                }

                // If we reach here, the response is valid JSON.
                // We no longer check for license_status === 'valid' here.
                // The server is expected to return the update info if available, regardless of license.
                // The decision to show/install the update is now based purely on version_compare in inject_update.
                // securepay_bridge_log("Plugin Updater: Successfully queried update server for action '$action'. Received valid data.");
                return $data; // Return the decoded object
            }
        }
        ?>
