<?php
        // Get the current URL
        $ctrlhcurrentUrl = $_SERVER['REQUEST_URI'];

        // Parse the URL
        $ctrlhurlParts = parse_url($ctrlhcurrentUrl);

        // Extract the query string
        $ctrlhqueryString = isset($ctrlhurlParts['query']) ? $ctrlhurlParts['query'] : '';
        parse_str($ctrlhqueryString, $query_params);

        // Ensure order_key is set if available in GET (or you may use COOKIE if needed)
        if (!isset($query_params['order_key']) && isset($_GET['order_key'])) {
            $query_params['order_key'] = $_GET['order_key'];
        }

        // Rebuild query string
        $ctrlhqueryString = http_build_query($query_params);

        // Remove leading and trailing slashes from path
        $ctrlhpath = trim($ctrlhurlParts['path'], '/');

        // Explode the path by slashes
        $ctrlhpathParts = explode('/', $ctrlhpath);

        // Calculate the number of directories to go up
        $ctrlhnumDirectories = count($ctrlhpathParts) - 3; // 3 directories up

        // Construct the new URL
        $ctrlhnewUrl = '/';
        if ($ctrlhnumDirectories > 0) {
            $ctrlhnewUrl .= str_repeat('../', $ctrlhnumDirectories);
        }
        $ctrlhnewUrl .= '?' . $ctrlhqueryString;

        // Perform the redirection
        header("Referrer-Policy: no-referrer");
        header("Location: $ctrlhnewUrl");
        exit;
        ?>
